import { createEntitlementToken, json } from './lib/payments.mjs';
import { fetchSubscription, isSubscriptionActive } from './lib/cashfree-subscriptions.mjs';

/** Reads a subscription's live state from Cashfree and issues an entitlement. */
export async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed.' });

  const subscriptionId = String(event.queryStringParameters?.subscription_id || '');
  if (!/^ts_sub_[a-z0-9_]+$/i.test(subscriptionId)) {
    return json(400, { error: 'Invalid ThinkSharp subscription.' });
  }

  try {
    const subscription = await fetchSubscription(subscriptionId);
    const active = isSubscriptionActive(subscription);

    // Tier and period come from OUR id format, never from anything the client sent.
    const tier = /^ts_sub_unabridged_/i.test(subscriptionId) ? 'unabridged' : 'ultimate';
    const months = /_yearly_/i.test(subscriptionId) ? 12 : 1;

    const entitlement = active
      ? createEntitlementToken({
          email: String(subscription.customer_details?.customer_email || ''),
          tier,
          months,
        })
      : null;

    return json(200, {
      provider: 'cashfree',
      subscriptionId,
      subscriptionStatus: subscription.subscription_status || 'UNKNOWN',
      isPaid: active,
      isExpired: ['CANCELLED', 'COMPLETED', 'EXPIRED'].includes(
        String(subscription.subscription_status || '').toUpperCase(),
      ),
      subscriptionTier: tier,
      nextPaymentOn: subscription.subscription_next_payment_on || null,
      entitlementToken: entitlement?.token || null,
      expiresAt: entitlement?.expiresAt || null,
    });
  } catch (error) {
    console.error('Subscription verification failed:', error);
    return json(error.statusCode || 502, { error: error.message || 'Could not verify that subscription.' });
  }
}
