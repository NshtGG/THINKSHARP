import { cashfreeConfig, coinbaseConfig, fable5Configured, json } from './lib/payments.mjs';

/**
 * Reports which payment rails are actually live.
 *
 * Without this the app happily showed a "Pay ₹2,000" button, collected a phone
 * number, and only then surfaced a raw 503 string from the provider — which
 * reads to a user like the payment failed rather than like it was never set up.
 * Letting someone reach the last step of a checkout that cannot exist is the
 * worst possible ordering.
 *
 * Returns booleans only. It deliberately never echoes a key, a key prefix, or a
 * length, because this endpoint is public.
 */
export async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed.' });

  const cashfree = cashfreeConfig();
  const coinbase = coinbaseConfig();

  const cardsAndUpi = cashfree.configured;
  const crypto = coinbase.configured;
  const unabridged = cashfree.configured && fable5Configured();

  return json(200, {
    // Which checkout methods can actually be started.
    methods: {
      upi: cardsAndUpi,
      cashfree: cardsAndUpi,
      card: cardsAndUpi,
      crypto,
    },
    tiers: {
      ultimate: cardsAndUpi || crypto,
      unabridged,
    },
    // Recurring mandates need the same Cashfree keys, plus a webhook secret
    // before renewals and failures can be acted on.
    subscriptions: {
      upi: cardsAndUpi,
      card: cardsAndUpi,
      enach: cardsAndUpi,
      webhooksLive: Boolean(process.env.CASHFREE_WEBHOOK_SECRET),
    },
    // Sandbox means real cards are declined — worth saying out loud in the UI.
    mode: cashfree.configured ? cashfree.environment : null,
    anyLive: cardsAndUpi || crypto,
    // Named so the owner can see what is missing without reading server logs.
    missing: [
      !cashfree.configured && 'CASHFREE_CLIENT_ID + CASHFREE_CLIENT_SECRET',
      !coinbase.configured && 'COINBASE_COMMERCE_API_KEY',
      !process.env.THINKSHARP_ENTITLEMENT_SECRET && 'THINKSHARP_ENTITLEMENT_SECRET',
      !process.env.ANTHROPIC_API_KEY && 'ANTHROPIC_API_KEY',
      !process.env.CASHFREE_WEBHOOK_SECRET && 'CASHFREE_WEBHOOK_SECRET (renewals + failed debits)',
    ].filter(Boolean),
  });
}
