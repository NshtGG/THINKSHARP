import { createSign } from 'node:crypto';
import { createEntitlementToken, json } from './lib/payments.mjs';

/**
 * Verifies a Google Play subscription purchase and issues an entitlement.
 *
 * A purchase token from the client proves nothing — it is just a string the app
 * handed us, and a rooted device or a patched APK can produce any string it
 * likes. The only thing that counts is Google's own answer, so this asks the
 * Play Developer API directly and trusts nothing else.
 *
 * Setup (Play Console + Google Cloud):
 *   1. Play Console -> Setup -> API access -> link a Google Cloud project.
 *   2. Create a service account, grant it "View financial data" and
 *      "Manage orders and subscriptions" on the app.
 *   3. Download the JSON key and set these environment variables:
 *        GOOGLE_PLAY_SA_EMAIL        client_email from the JSON
 *        GOOGLE_PLAY_SA_PRIVATE_KEY  private_key from the JSON (keep the \n)
 *        ANDROID_PACKAGE_NAME        app.thinksharp.journal
 */

const PACKAGE = process.env.ANDROID_PACKAGE_NAME || 'app.thinksharp.journal';

/** Product id -> what it entitles you to. The client cannot influence this. */
const PRODUCTS = {
  thinksharp_ultimate_monthly: { tier: 'ultimate', months: 1 },
  thinksharp_ultimate_yearly: { tier: 'ultimate', months: 12 },
  thinksharp_unabridged_monthly: { tier: 'unabridged', months: 1 },
  thinksharp_unabridged_yearly: { tier: 'unabridged', months: 12 },
};

function base64url(input) {
  return Buffer.from(input).toString('base64url');
}

/** Mints a short-lived OAuth token for the service account (JWT bearer flow). */
async function getAccessToken() {
  const email = process.env.GOOGLE_PLAY_SA_EMAIL;
  const key = (process.env.GOOGLE_PLAY_SA_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  if (!email || !key) return null;

  const now = Math.floor(Date.now() / 1000);
  const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claims = base64url(
    JSON.stringify({
      iss: email,
      scope: 'https://www.googleapis.com/auth/androidpublisher',
      aud: 'https://oauth2.googleapis.com/token',
      iat: now,
      exp: now + 3600,
    }),
  );
  const signature = createSign('RSA-SHA256').update(`${header}.${claims}`).sign(key, 'base64url');

  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: `${header}.${claims}.${signature}`,
    }),
  });
  if (!response.ok) {
    console.error('Play service-account token exchange failed:', await response.text());
    return null;
  }
  return (await response.json()).access_token;
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid purchase payload.' });
  }

  const productId = String(payload.productId || '');
  const purchaseToken = String(payload.purchaseToken || '');
  const email = String(payload.email || '').trim().toLowerCase();

  const product = PRODUCTS[productId];
  if (!product) return json(400, { error: 'Unknown product.' });
  if (!purchaseToken) return json(400, { error: 'Missing purchase token.' });

  const accessToken = await getAccessToken();
  if (!accessToken) {
    return json(503, {
      error: 'Play purchase verification is not configured yet. Add GOOGLE_PLAY_SA_EMAIL and GOOGLE_PLAY_SA_PRIVATE_KEY.',
    });
  }

  try {
    const url =
      `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(PACKAGE)}` +
      `/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`;
    const response = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
    const result = await response.json();

    if (!response.ok) {
      console.error('Play verification failed:', result);
      return json(response.status === 404 ? 404 : 502, {
        error: response.status === 404 ? 'That purchase could not be found on Google Play.' : 'Google Play could not verify this purchase.',
      });
    }

    // Only these two states mean the person may use what they paid for.
    const state = String(result.subscriptionState || '');
    const active = state === 'SUBSCRIPTION_STATE_ACTIVE' || state === 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD';
    if (!active) {
      return json(200, { isPaid: false, subscriptionState: state, entitlementToken: null });
    }

    // Trust the tier from OUR product table, never from the request body.
    const entitlement = createEntitlementToken({
      email,
      tier: product.tier,
      months: product.months,
    });

    return json(200, {
      isPaid: true,
      subscriptionState: state,
      subscriptionTier: product.tier,
      billingPeriod: product.months === 12 ? 'yearly' : 'monthly',
      expiryTime: result.lineItems?.[0]?.expiryTime || null,
      entitlementToken: entitlement?.token || null,
      expiresAt: entitlement?.expiresAt || null,
      // The app should acknowledge only after seeing this. Play refunds a
      // subscription that goes unacknowledged for three days.
      shouldAcknowledge: result.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_PENDING',
    });
  } catch (error) {
    console.error('Play verification request failed:', error);
    return json(502, { error: 'Unable to reach Google Play. Please try again.' });
  }
}
