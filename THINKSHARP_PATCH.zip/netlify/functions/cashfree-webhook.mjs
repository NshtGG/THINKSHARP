import { createHmac, timingSafeEqual } from 'node:crypto';
import { json } from './lib/payments.mjs';

/**
 * Cashfree webhook receiver.
 *
 * Without this, ThinkSharp only ever learns about a payment if the customer's
 * browser makes it back to the return URL. That misses everything that matters
 * over the life of a subscription: the renewal that goes through next month,
 * the debit that bounces, the mandate the customer cancels from their bank app,
 * a refund, a chargeback. Polling from the client cannot see any of it, because
 * the client is not open when it happens.
 *
 * Set CASHFREE_WEBHOOK_SECRET and point Cashfree at:
 *   https://<your-domain>/.netlify/functions/cashfree-webhook
 */

/**
 * Cashfree signs `timestamp + rawBody` with the webhook secret.
 * Rejecting unsigned requests matters: this endpoint is public, and anything
 * that trusts its body could be told a subscription is active by anyone.
 */
function signatureValid(rawBody, timestamp, signature) {
  const secret = process.env.CASHFREE_WEBHOOK_SECRET;
  if (!secret || !signature || !timestamp) return false;
  const expected = createHmac('sha256', secret).update(`${timestamp}${rawBody}`).digest('base64');
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });

  const raw = event.body || '';
  const timestamp = event.headers['x-webhook-timestamp'] || event.headers['X-Webhook-Timestamp'];
  const signature = event.headers['x-webhook-signature'] || event.headers['X-Webhook-Signature'];

  if (!process.env.CASHFREE_WEBHOOK_SECRET) {
    console.error('Webhook received but CASHFREE_WEBHOOK_SECRET is not set — ignoring.');
    return json(503, { error: 'Webhooks are not configured.' });
  }
  if (!signatureValid(raw, timestamp, signature)) {
    console.error('Rejected a webhook with an invalid signature.');
    return json(401, { error: 'Invalid signature.' });
  }

  let payload;
  try { payload = JSON.parse(raw); }
  catch { return json(400, { error: 'Invalid webhook payload.' }); }

  const type = String(payload.type || payload.event_type || '');
  const data = payload.data || {};
  const subscriptionId = data.subscription_details?.subscription_id || data.subscription_id || null;

  // Cashfree retries anything that is not 2xx, so this logs and acknowledges
  // rather than erroring on event types we do not act on yet.
  switch (type) {
    case 'SUBSCRIPTION_STATUS_CHANGE':
    case 'SUBSCRIPTION_NEW_PAYMENT':
      console.log(`[cashfree] ${type} for ${subscriptionId}: ${data.subscription_details?.subscription_status || 'n/a'}`);
      break;

    case 'SUBSCRIPTION_PAYMENT_DECLINED':
      // A failed renewal. The customer keeps access until the entitlement
      // expires naturally, which is the right grace behaviour — but this is
      // where a dunning email belongs once mail is wired up.
      console.warn(`[cashfree] payment declined for ${subscriptionId}`);
      break;

    case 'SUBSCRIPTION_CANCELLED':
      console.log(`[cashfree] cancelled: ${subscriptionId}`);
      break;

    case 'PAYMENT_SUCCESS_WEBHOOK':
    case 'PAYMENT_FAILED_WEBHOOK':
    case 'PAYMENT_USER_DROPPED_WEBHOOK':
      console.log(`[cashfree] ${type} for order ${data.order?.order_id || 'n/a'}`);
      break;

    default:
      console.log(`[cashfree] unhandled event ${type}`);
  }

  // ThinkSharp keeps no server-side user store yet, so entitlement still comes
  // from verify-subscription when the app next opens. Once accounts live on a
  // backend, this is the hook that should write the change immediately.
  return json(200, { received: true, type });
}
