import {
  isEmail, json, normalizeCountry, normalizePeriod, normalizePhone,
  normalizeTier, resolvePlan, safeId, appUrl, fable5Configured,
} from './lib/payments.mjs';
import { createSubscription, normalizeSubscriptionMethod, SUBSCRIPTION_METHODS } from './lib/cashfree-subscriptions.mjs';

/**
 * Starts a genuinely recurring Cashfree subscription.
 *
 * create-payment-order stays for one-off charges, but a *plan* should use this:
 * the customer approves a mandate once and is debited every cycle
 * automatically, instead of paying once and silently lapsing.
 */
export async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });

  let payload;
  try { payload = JSON.parse(event.body || '{}'); }
  catch { return json(400, { error: 'Invalid subscription request.' }); }

  const tier = normalizeTier(payload.subscriptionTier);
  const period = normalizePeriod(payload.billingPeriod);
  const country = normalizeCountry(payload.country);
  const method = normalizeSubscriptionMethod(payload.method);
  const customer = payload.customer || {};

  const email = String(customer.email || '').trim().toLowerCase();
  const name = String(customer.name || '').trim().slice(0, 80) || 'ThinkSharp member';
  if (!isEmail(email)) return json(400, { error: 'A valid email address is required.' });

  const phone = normalizePhone(customer.phone, country);
  if (!phone) {
    return json(400, {
      error: country === 'IN'
        ? 'Enter a valid 10-digit Indian mobile number.'
        : 'Enter a valid mobile number (8-15 digits).',
    });
  }

  // UPI Autopay and eNACH are Indian rails; anyone else must use a card mandate.
  if (SUBSCRIPTION_METHODS[method].indiaOnly && country !== 'IN') {
    return json(400, { error: `${SUBSCRIPTION_METHODS[method].label} is available in India only. Choose card instead.` });
  }

  if (tier === 'unabridged' && !fable5Configured()) {
    return json(503, { error: 'Unabridged is not configured yet on the server.' });
  }

  let plan;
  try { plan = resolvePlan({ tier, country, method: 'cashfree', period }); }
  catch (error) { return json(error.statusCode || 400, { error: error.message }); }

  const subscriptionId = `ts_sub_${tier}_${period}_${safeId(email.split('@')[0]) || 'member'}_${Date.now().toString(36)}`.slice(0, 60);

  try {
    const result = await createSubscription({
      tier, period, method,
      customer: { name, email, phone },
      currency: plan.charge.currency,
      perMonth: plan.charge.perMonth,
      returnUrl: `${appUrl()}/?ts_subscription_id=${encodeURIComponent(subscriptionId)}`,
      subscriptionId,
    });
    return json(200, { ...result, tier, period, method });
  } catch (error) {
    console.error('Subscription creation failed:', error);
    return json(error.statusCode || 502, { error: error.message || 'Could not start that subscription.' });
  }
}
