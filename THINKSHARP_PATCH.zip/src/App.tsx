import { useEffect, useMemo, useRef, useState } from 'react';
import type { ElementType, PointerEvent as ReactPointerEvent } from 'react';
import DrawRounded from '@mui/icons-material/DrawRounded';
import EditRounded from '@mui/icons-material/EditRounded';
import EmojiEventsRounded from '@mui/icons-material/EmojiEventsRounded';
import HistoryRounded from '@mui/icons-material/HistoryRounded';
import InsightsRounded from '@mui/icons-material/InsightsRounded';
import OpenInFullRounded from '@mui/icons-material/OpenInFullRounded';
import SettingsRounded from '@mui/icons-material/SettingsRounded';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Crown,
  Download,
  Flame,
  Globe2,
  Lock,
  LogOut,
  Moon,
  PenLine,
  Search,
  Shuffle,
  Sparkles,
  Sun,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { MusicPlayer } from './components/MusicPlayer';
import { PremiumModal, PRICING, detectCountry, getTierPrice } from './components/PremiumModal';
import type { SubscriptionTier } from './components/PremiumModal';
import { NatureBackground, DARK_VARS, LIGHT_VARS } from './components/NatureBackground';
import { SubscriptionAuthModal, SubscriptionAuthData } from './components/SubscriptionAuthModal';
import {
  clearPendingOrder,
  clearPendingSubscription,
  readPendingOrder,
  readPendingSubscription,
  startPayment,
  startSubscription,
  verifyPaymentOrder,
  verifySubscription,
  waitForPaidOrder,
} from './utils/payments';
import type { BillingPeriod, MandateMethod, PaymentMethod } from './utils/payments';
import { requestFable5Reflection, requestJournalSummary } from './utils/fable';
import {
  finishPlayTransaction,
  hasVerificationBackend,
  initPlayBilling,
  isPlayBillingPlatform,
  purchaseWithPlay,
  restorePlayPurchases,
  verifyPlayPurchase,
  verifyWithPlayLocally,
} from './utils/playBilling';
import type { JournalSummary } from './utils/fable';

// ---------- Types ----------

type Tab = 'journal' | 'leaderboard' | 'entries' | 'analysis' | 'settings';

type Entry = {
  id: string;
  prompt: string;
  content: string;
  mood: number; // 1-5
  words: number;
  createdAt: string;
  /** PNG data URL of anything handwritten or sketched for this entry. */
  drawing?: string;
};

type AppSettings = {
  name: string;
  model: string;
  premium: boolean;
  subscriptionTier: SubscriptionTier | null;
  entitlementToken: string | null;
  subscriptionExpiresAt: number | null;
  country: string;
  theme: 'dark' | 'light';
};

// ---------- Constants ----------

const ENTRIES_KEY = 'thinksharp_entries';
const SETTINGS_KEY = 'thinksharp_settings';
const FIRST_USE_KEY = 'thinksharp_first_use';
const AUTH_KEY = 'thinksharp_auth';
const TRIAL_DAYS = 3;
const FREE_WORD_LIMIT = 5000;

const PROMPTS = [
  'What felt heavier than it looked today?',
  'What did you handle better than your past self would have?',
  'What are you avoiding, and what would a kinder first step look like?',
  'Which moment today made you feel most like yourself?',
  'What pattern keeps repeating in your life lately?',
  'If you slowed down for ten minutes tomorrow, what would you notice?',
  'What would you like to forgive yourself for this week?',
  'Where did your energy go today — and what gave any back?',
  'What is one thing you know now that you did not know a month ago?',
  'What small thing are you quietly proud of?',
  'What is one worry you can set down, just for tonight?',
  'Who made you feel seen recently, and how?',
];

const MOODS = [
  { value: 1, emoji: '😞', label: 'Rough' },
  { value: 2, emoji: '😟', label: 'Low' },
  { value: 3, emoji: '😐', label: 'Okay' },
  { value: 4, emoji: '🙂', label: 'Good' },
  { value: 5, emoji: '😄', label: 'Great' },
];

const BOTS = [
  { name: 'Mira', emoji: '🦊', streak: 21, xp: 4180 },
  { name: 'Kenji', emoji: '🐢', streak: 14, xp: 3350 },
  { name: 'Sana', emoji: '🌙', streak: 9, xp: 2140 },
  { name: 'Leo', emoji: '🔥', streak: 6, xp: 1580 },
  { name: 'Ava', emoji: '🍵', streak: 3, xp: 760 },
];

/**
 * Words that carry no signal about what someone is actually writing about.
 *
 * This list used to be ~50 words, which was nowhere near enough: on a real
 * 20-entry journal the "recurring words" insight came back as
 * "which, something, minutes, time, said" — pure grammatical filler — and the
 * personalised question became: '"which" keeps appearing in your writing.
 * What is it really about?' Anything that survives this list should be a word
 * a person would recognise as a topic.
 */
const STOP_WORDS = new Set([
  // determiners, pronouns, conjunctions
  'about', 'above', 'after', 'again', 'against', 'because', 'been', 'before', 'behind', 'being', 'below',
  'between', 'both', 'could', 'does', 'doing', 'done', 'down', 'during', 'each', 'either', 'else', 'even',
  'ever', 'every', 'from', 'have', 'having', 'here', 'hers', 'herself', 'himself', 'into', 'itself', 'just',
  'like', 'mine', 'more', 'most', 'much', 'must', 'myself', 'never', 'next', 'none', 'nothing', 'once',
  'only', 'other', 'others', 'ours', 'ourselves', 'over', 'same', 'shall', 'should', 'since', 'some',
  'somebody', 'someone', 'something', 'sometimes', 'still', 'such', 'than', 'that', 'thats', 'their',
  'theirs', 'them', 'themselves', 'then', 'there', 'these', 'they', 'thing', 'things', 'this', 'those',
  'though', 'through', 'toward', 'under', 'until', 'upon', 'very', 'were', 'what', 'when', 'where',
  'whether', 'which', 'while', 'whom', 'whose', 'will', 'with', 'within', 'without', 'would', 'your',
  'yours', 'yourself',
  // contractions once punctuation is stripped
  'cant', 'didnt', 'doesnt', 'dont', 'hadnt', 'hasnt', 'havent', 'isnt', 'ive', 'thats', 'theres',
  'wasnt', 'werent', 'wont', 'wouldnt', 'youre', 'youve', 'theyre', 'thats',
  // journalling filler — extremely common in every entry, so never distinctive
  'actually', 'almost', 'already', 'also', 'always', 'anything', 'basically', 'bit', 'called', 'came',
  'come', 'completely', 'coming', 'day', 'days', 'enough', 'everything', 'exactly', 'feel', 'feeling',
  'felt', 'genuinely', 'getting', 'give', 'going', 'gone', 'good', 'got', 'guess', 'half', 'hour',
  'hours', 'idea', 'keep', 'keeps', 'kept', 'kind', 'know', 'known', 'knows', 'less', 'little',
  'long', 'look', 'looked', 'looking', 'lot', 'made', 'make', 'makes', 'making', 'many', 'maybe', 'mean',
  'means', 'meant', 'minute', 'minutes', 'moment', 'month', 'months', 'morning', 'need', 'needed', 'night',
  'notice', 'noticed', 'now', 'nine', 'pretty', 'probably', 'put', 'quite', 'rather', 'really', 'right',
  'said', 'say', 'saying', 'says', 'see', 'seen', 'sort', 'started', 'stuff', 'sure', 'take', 'taken',
  'tell', 'thought', 'thoughts', 'three', 'time', 'times', 'today', 'tomorrow', 'tonight', 'took', 'two',
  'used', 'using', 'want', 'wanted', 'wants', 'way', 'week', 'weeks', 'well', 'went', 'whole', 'year',
  'years', 'yesterday',
  // caught by running this on a real 20-entry journal and reading the result
  'able', 'across', 'anyone', 'anymore', 'away', 'back', 'best', 'better', 'everyone', 'first', 'gets',
  'hard', 'help', 'himself', 'last', 'later', 'least', 'nobody', 'off', 'okay', 'open', 'own', 'past',
  'part', 'person', 'point', 'read', 'ready', 'reason', 'seems', 'small', 'someones', 'stop', 'stopped',
  'talk', 'told', 'turn', 'until', 'wait', 'waiting', 'whats', 'wrong', 'yeah',
]);

// ---------- Helpers ----------

function createId() {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function todayPromptIndex() {
  const day = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
  return day % PROMPTS.length;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat('en', { weekday: 'short', month: 'short', day: 'numeric' }).format(new Date(value));
}

function formatTime(value: string) {
  return new Intl.DateTimeFormat('en', { hour: 'numeric', minute: '2-digit' }).format(new Date(value));
}

function countWords(text: string) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function getStreak(entries: Entry[]) {
  if (!entries.length) return 0;
  const days = Array.from(new Set(entries.map((e) => new Date(e.createdAt).toISOString().slice(0, 10)))).sort(
    (a, b) => (a < b ? 1 : -1)
  );
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  if (days[0] !== today && days[0] !== yesterday) return 0;

  let streak = 1;
  let current = new Date(days[0]);
  for (let i = 1; i < days.length; i += 1) {
    const next = new Date(days[i]);
    const diff = Math.round((current.getTime() - next.getTime()) / 86400000);
    if (diff === 1) {
      streak += 1;
      current = next;
    } else break;
  }
  return streak;
}

/**
 * The words a person actually keeps returning to.
 *
 * A word only counts as "recurring" if it shows up on more than one day —
 * otherwise a single long entry about one subject floods the list and looks
 * like a long-term pattern. We also require it to appear at least twice
 * overall, so one-offs never surface as insight.
 */
function topWords(entries: Entry[], limit = 6) {
  const total = new Map<string, number>();
  const daysSeen = new Map<string, Set<string>>();

  entries.forEach((entry) => {
    const day = new Date(entry.createdAt).toISOString().slice(0, 10);
    const seenHere = new Set<string>();
    tokenize(entry.content)
      .filter((w) => w.length > 3 && !STOP_WORDS.has(w))
      .forEach((w) => {
        total.set(w, (total.get(w) ?? 0) + 1);
        seenHere.add(w);
      });
    seenHere.forEach((w) => {
      if (!daysSeen.has(w)) daysSeen.set(w, new Set());
      daysSeen.get(w)!.add(day);
    });
  });

  return Array.from(total.entries())
    .filter(([word, count]) => count >= 2 && (daysSeen.get(word)?.size ?? 0) >= 2)
    // Rank by how many separate days it appears on first, then raw frequency.
    .sort((a, b) => (daysSeen.get(b[0])!.size - daysSeen.get(a[0])!.size) || (b[1] - a[1]))
    .slice(0, limit)
    .map(([word]) => word);
}

const THEME_BUCKETS = [
  { label: 'Work pressure', words: ['work', 'working', 'job', 'task', 'tasks', 'deadline', 'deadlines', 'meeting', 'meetings', 'email', 'emails', 'busy', 'boss', 'manager', 'team', 'project', 'client', 'office', 'role', 'promotion', 'workload', 'overtime'] },
  { label: 'Rest & recovery', words: ['rest', 'rested', 'resting', 'sleep', 'slept', 'sleeping', 'nap', 'tired', 'exhausted', 'exhaustion', 'burnout', 'recover', 'recovery', 'breath', 'breathe', 'breathing', 'quiet', 'calm', 'slow', 'pause'] },
  { label: 'Anxiety & overwhelm', words: ['anxious', 'anxiety', 'worry', 'worried', 'worrying', 'dread', 'panic', 'stress', 'stressed', 'overwhelmed', 'overwhelm', 'nervous', 'afraid', 'scared', 'fear', 'tense', 'tight', 'spiral', 'catastrophise', 'catastrophize'] },
  { label: 'Avoidance & procrastination', words: ['avoid', 'avoiding', 'avoided', 'avoidance', 'putting', 'postpone', 'postponed', 'delay', 'delayed', 'procrastinate', 'procrastinating', 'ignoring', 'ignored', 'silence', 'quietly', 'unanswered'] },
  { label: 'Self-trust', words: ['trust', 'trusting', 'forgive', 'forgiving', 'gentle', 'honest', 'honesty', 'proud', 'confidence', 'confident', 'doubt', 'doubting', 'worth', 'ashamed', 'shame', 'guilt', 'guilty'] },
  { label: 'Relationships', words: ['friend', 'friends', 'friendship', 'partner', 'family', 'mother', 'father', 'sister', 'brother', 'conversation', 'people', 'talked', 'talking', 'called', 'reply', 'replied', 'message', 'lonely', 'alone'] },
  { label: 'Clarity & direction', words: ['clarity', 'clear', 'plan', 'planning', 'direction', 'decision', 'decide', 'deciding', 'goal', 'goals', 'choice', 'choose', 'future', 'career', 'purpose'] },
  { label: 'Body & movement', words: ['run', 'ran', 'running', 'walk', 'walked', 'walking', 'gym', 'exercise', 'workout', 'yoga', 'swim', 'stretch', 'body', 'ache', 'sore', 'legs', 'calves'] },
];

/** Lowercased word list, punctuation stripped. Shared by every text analysis. */
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    // Strip apostrophes (including the typographic ’) without splitting the
    // word, so "didn't" -> "didnt" and matches the stop list, rather than
    // becoming "didn" and surfacing as a recurring word.
    .replace(/['\u2018\u2019]/g, '')
    .replace(/[^a-z\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

/**
 * Which subject dominates a stretch of entries.
 *
 * The previous version scored `text.includes(word)`, which had two bugs that
 * compounded: it matched substrings (so "rest" fired on "restructuring" and
 * "interesting", "tea" fired on "team"), and it scored mere presence, so a word
 * used once counted the same as a word used forty times. On a real journal that
 * was overwhelmingly about work anxiety, "Rest & recovery" beat "Work pressure"
 * 7-4 entirely on accidental substring hits.
 *
 * Now: whole-word matching, counted by frequency, and normalised by bucket size
 * so a bucket does not win simply by listing more keywords.
 */
function inferTheme(entries: Entry[]) {
  if (!entries.length) return 'Everyday reflection';
  const words = tokenize(entries.map((e) => `${e.prompt} ${e.content}`).join(' '));
  const counts = new Map<string, number>();
  words.forEach((w) => counts.set(w, (counts.get(w) ?? 0) + 1));

  const ranked = THEME_BUCKETS
    .map((bucket) => {
      const hits = bucket.words.reduce((sum, w) => sum + (counts.get(w) ?? 0), 0);
      const distinct = bucket.words.filter((w) => counts.has(w)).length;
      // Frequency drives the score; requiring 2+ distinct keywords stops a
      // single repeated word from defining the whole theme.
      return { label: bucket.label, score: distinct >= 2 ? hits / Math.sqrt(bucket.words.length) : 0 };
    })
    .sort((a, b) => b.score - a.score);

  return ranked[0]?.score ? ranked[0].label : 'Everyday reflection';
}

function suggestPrompt(avgMood: number) {
  if (avgMood <= 2) return 'What can be made smaller, softer, or slower tomorrow?';
  if (avgMood < 3.5) return 'What is the next clear thing — not the whole plan?';
  if (avgMood < 4.5) return 'What tiny action would make this momentum real by tonight?';
  return 'What do you want to protect from this week and repeat?';
}

function historyQuestions(entries: Entry[]): string[] {
  const theme = inferTheme(entries);
  const words = topWords(entries, 3);
  const questions: string[] = [];
  if (words[0]) questions.push(`"${words[0]}" keeps appearing in your writing. What is it really about?`);
  const themeQ: Record<string, string> = {
    'Work pressure': 'If work stopped being a scoreboard for a week, what would you do differently?',
    'Rest & recovery': 'What kind of rest actually restores you — and when did you last get it?',
    'Anxiety & overwhelm': 'When the dread shows up, what is it usually predicting — and how often has it been right?',
    'Avoidance & procrastination': 'What has been waiting longest for you, and what does the waiting cost you each day?',
    'Self-trust': 'What decision are you more ready to make than you admit?',
    'Relationships': 'Which relationship deserves ten more honest minutes from you this week?',
    'Clarity & direction': 'What would you attempt if the next step only had to be small, not correct?',
    'Body & movement': 'What does your body do differently on the days you feel most like yourself?',
    'Everyday reflection': 'Across your recent entries, what feels quietly different about you?',
  };
  questions.push(themeQ[theme] ?? themeQ['Everyday reflection']);
  if (words[1]) questions.push(`How has your relationship with "${words[1]}" changed since your earliest entries?`);
  return questions;
}

// ---------- App ----------

export default function App() {
  const [tab, setTab] = useState<Tab>('journal');
  const [entries, setEntries] = useState<Entry[]>(() => {
    try {
      const raw = localStorage.getItem(ENTRIES_KEY);
      return raw ? (JSON.parse(raw) as Entry[]) : [];
    } catch {
      return [];
    }
  });
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) {
        return {
          name: 'You',
          model: 'glm-4-flash',
          premium: false,
          subscriptionTier: null,
          entitlementToken: null,
          subscriptionExpiresAt: null,
          country: detectCountry(),
          theme: 'dark',
          ...JSON.parse(raw),
        };
      }
    } catch {
      // ignore
    }
    return {
      name: 'You',
      model: 'glm-4-flash',
      premium: false,
      subscriptionTier: null,
      entitlementToken: null,
      subscriptionExpiresAt: null,
      country: detectCountry(),
      theme: 'dark',
    };
  });

  const [firstUse] = useState<number>(() => {
    try {
      const raw = localStorage.getItem(FIRST_USE_KEY);
      if (raw) return Number(raw);
      const now = Date.now();
      localStorage.setItem(FIRST_USE_KEY, String(now));
      return now;
    } catch {
      return Date.now();
    }
  });

  const [promptIndex, setPromptIndex] = useState(todayPromptIndex());
  const [draft, setDraft] = useState('');
  const [mood, setMood] = useState(0);
  const [justSaved, setJustSaved] = useState(false);
  // expanded state removed per request
  const [premiumOpen, setPremiumOpen] = useState(false);
  const [drawMode, setDrawMode] = useState(false);
  const [writingExpanded, setWritingExpanded] = useState(false);
  const drawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const hasDrawingRef = useRef(false);
  const lastDrawPointRef = useRef<{ x: number; y: number } | null>(null);
  const [paymentNotice, setPaymentNotice] = useState('');
  const [fableReflection, setFableReflection] = useState('');
  const [fableError, setFableError] = useState('');
  const [fableLoading, setFableLoading] = useState(false);
  const [openEntryId, setOpenEntryId] = useState<string | null>(null);
  const [entrySearch, setEntrySearch] = useState('');
  const [summaryRequested, setSummaryRequested] = useState(false);
  const [summary, setSummary] = useState<JournalSummary | null>(null);
  const [summaryError, setSummaryError] = useState('');
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [leaderboardScope, setLeaderboardScope] = useState<'global' | 'friends'>('global');
  const [tappedTab, setTappedTab] = useState<Tab | null>(null);
  /**
   * The handwriting, held as a PNG while the canvas is unmounted.
   *
   * Closing the pad removes the <canvas> from the DOM, so reading it at save
   * time found nothing and the drawing was silently dropped — exactly the bug
   * the pad had before. Snapshot on close, restore on reopen.
   */
  const [pendingDrawing, setPendingDrawing] = useState<string | undefined>();
  const [dotX, setDotX] = useState(0);
  const dockRef = useRef<HTMLDivElement | null>(null);
  const dockButtonRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  // Stable per-device code so the invite shown never changes between launches.
  const [inviteCode] = useState(() => {
    try {
      const saved = localStorage.getItem('thinksharp_invite_code');
      if (saved) return saved;
      const code = Array.from({ length: 6 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 31)]).join('');
      localStorage.setItem('thinksharp_invite_code', code);
      return code;
    } catch {
      return 'THINKSHARP';
    }
  });
  // Friends live on the backend; until that exists this stays empty rather than
  // being filled with invented people.
  const [friends] = useState<{ name: string; emoji: string; streak: number; xp: number }[]>([]);

  // --- Auth ---
  const [auth, setAuth] = useState<SubscriptionAuthData | null>(() => {
    try {
      const raw = localStorage.getItem(AUTH_KEY);
      return raw ? (JSON.parse(raw) as SubscriptionAuthData) : null;
    } catch {
      return null;
    }
  });

  const [subscriptionAuthOpen, setSubscriptionAuthOpen] = useState(false);
  const [continueToCheckout, setContinueToCheckout] = useState(false);

  const handleAuth = (data: SubscriptionAuthData) => {
    try {
      localStorage.setItem(AUTH_KEY, JSON.stringify(data));
    } catch {
      // The modal already persisted what it could; the session still works.
    }
    setAuth(data);
    // Sync display name into settings if user hasn't customized it
    setSettings((s) => (s.name === 'You' ? { ...s, name: data.name } : s));
    setSubscriptionAuthOpen(false);
    if (continueToCheckout) {
      setContinueToCheckout(false);
      setPremiumOpen(true);
    }
  };

  const handleSignOut = () => {
    try {
      localStorage.removeItem(AUTH_KEY);
    } catch {
      // ignore
    }
    setAuth(null);
  };

  const openPremiumFlow = () => {
    if (!auth) {
      setContinueToCheckout(true);
      setSubscriptionAuthOpen(true);
      return;
    }
    setPremiumOpen(true);
  };

  const prepareDrawCanvas = (canvas: HTMLCanvasElement) => {
    const bounds = canvas.getBoundingClientRect();
    const scale = window.devicePixelRatio || 1;
    const targetWidth = Math.round(bounds.width * scale);
    const targetHeight = Math.round(bounds.height * scale);

    if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
      // Resizing a canvas wipes it, so carry the existing strokes across.
      // Without this, rotating the phone erased whatever had been written.
      let previous: HTMLCanvasElement | null = null;
      if (canvas.width > 1 && canvas.height > 1 && hasDrawingRef.current) {
        previous = document.createElement('canvas');
        previous.width = canvas.width;
        previous.height = canvas.height;
        previous.getContext('2d')?.drawImage(canvas, 0, 0);
      }
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const context = canvas.getContext('2d');
      context?.setTransform(scale, 0, 0, scale, 0, 0);
      if (previous && context) {
        context.drawImage(previous, 0, 0, bounds.width, bounds.height);
      }
    }
    return canvas.getContext('2d');
  };

  const readDrawPoint = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
  };

  const startDrawing = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    event.preventDefault();
    const canvas = event.currentTarget;
    const context = prepareDrawCanvas(canvas);
    const point = readDrawPoint(event);
    if (!context) return;

    canvas.setPointerCapture(event.pointerId);
    context.beginPath();
    context.moveTo(point.x, point.y);
    context.strokeStyle = '#F5F5F5';
    context.lineCap = 'round';
    context.lineJoin = 'round';
    context.lineWidth = event.pointerType === 'pen' ? Math.max(1.5, event.pressure * 5) : 3;
    drawingRef.current = true;
    hasDrawingRef.current = true;
    lastDrawPointRef.current = point;
  };

  const drawLine = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || !lastDrawPointRef.current) return;
    event.preventDefault();
    const context = prepareDrawCanvas(event.currentTarget);
    const point = readDrawPoint(event);
    if (!context) return;

    context.lineWidth = event.pointerType === 'pen' ? Math.max(1.5, event.pressure * 5) : 3;
    context.beginPath();
    context.moveTo(lastDrawPointRef.current.x, lastDrawPointRef.current.y);
    context.lineTo(point.x, point.y);
    context.stroke();
    lastDrawPointRef.current = point;
  };

  const stopDrawing = () => {
    drawingRef.current = false;
    lastDrawPointRef.current = null;
  };

  const clearDrawing = () => {
    const canvas = drawCanvasRef.current;
    const context = canvas?.getContext('2d');
    if (canvas && context) {
      context.save();
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.restore();
    }
    hasDrawingRef.current = false;
    setPendingDrawing(undefined);
  };

  /** The handwriting as a PNG, or undefined when nothing was drawn. */
  const captureDrawing = (): string | undefined => {
    if (!hasDrawingRef.current) return pendingDrawing;
    try {
      return drawCanvasRef.current?.toDataURL('image/png') || pendingDrawing;
    } catch {
      return pendingDrawing;
    }
  };

  /** Leave the pad, keeping whatever was written. */
  const closeDrawing = () => {
    setPendingDrawing(captureDrawing());
    setDrawMode(false);
  };

  // Put the saved strokes back when the pad is reopened.
  useEffect(() => {
    if (!drawMode || !pendingDrawing) return;
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const image = new Image();
    image.onload = () => {
      const bounds = canvas.getBoundingClientRect();
      const context = prepareDrawCanvas(canvas);
      if (!context) return;
      context.drawImage(image, 0, 0, bounds.width, bounds.height);
      hasDrawingRef.current = true;
    };
    image.src = pendingDrawing;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drawMode]);

  const runFable5Reflection = async (entriesForReflection: Entry[]) => {
    if (!settings.entitlementToken) {
      setFableError('Your Fable 5 entitlement is unavailable. Renew or reopen your Fable 5 checkout.');
      return;
    }

    setFableError('');
    setFableLoading(true);
    try {
      const result = await requestFable5Reflection(entriesForReflection, settings.entitlementToken);
      setFableReflection(result.reflection);
    } catch (error) {
      setFableError(error instanceof Error ? error.message : 'Fable 5 could not create a reflection.');
    } finally {
      setFableLoading(false);
    }
  };

  const runJournalSummary = async () => {
    if (!settings.entitlementToken) {
      setSummaryError('Your subscription could not be verified on this device. Reopen your plan to refresh it.');
      return;
    }
    setSummaryError('');
    setSummaryLoading(true);
    try {
      setSummary(await requestJournalSummary(sorted, settings.entitlementToken));
    } catch (error) {
      setSummaryError(error instanceof Error ? error.message : 'Your journal summary could not be created.');
    } finally {
      setSummaryLoading(false);
    }
  };

  const activatePaidPlan = (verification: {
    subscriptionTier?: SubscriptionTier;
    entitlementToken?: string | null;
    expiresAt?: number | null;
    provider?: string;
  }, fallbackTier: SubscriptionTier) => {
    const paidTier = verification.subscriptionTier || fallbackTier;
    setSettings((current) => ({
      ...current,
      premium: true,
      subscriptionTier: paidTier,
      entitlementToken: verification.entitlementToken || null,
      subscriptionExpiresAt: verification.expiresAt || null,
    }));
    const processor = verification.provider === 'coinbase' ? 'the crypto network' : 'Cashfree';
    setPaymentNotice(`Payment confirmed by ${processor}. ThinkSharp ${paidTier === 'unabridged' ? 'Unabridged' : 'Ultimate'} is now active.`);
  };

  /**
   * Returns true when the payment finished inline, false when the browser is
   * being redirected to a hosted checkout (crypto).
   */
  const handlePayment = async (
    method: PaymentMethod,
    phone: string,
    requestedTier: SubscriptionTier,
    billingPeriod: BillingPeriod,
  ): Promise<boolean> => {
    if (!auth) throw new Error('Please sign in before starting payment.');

    // Inside the Android app, Google Play is the only permitted way to sell a
    // subscription. Cashfree and crypto stay on the web build.
    if (isPlayBillingPlatform()) {
      const purchase = await purchaseWithPlay(requestedTier, billingPeriod);
      // Prefer server verification; fall back to Play's own receipt so the app
      // can sell subscriptions before any backend exists.
      const verification = hasVerificationBackend()
        ? await verifyPlayPurchase(purchase, auth.email)
        : await verifyWithPlayLocally(purchase);
      if (!verification.isPaid) {
        throw new Error('Google Play has not confirmed that purchase yet. It will unlock as soon as it does.');
      }
      // Acknowledge only now. Play refunds anything left unacknowledged for
      // three days, which is the right result if verification never succeeds.
      finishPlayTransaction(purchase.productId);
      activatePaidPlan(verification, requestedTier);
      return true;
    }

    // Web: set up a real mandate so the plan actually renews. The old path
    // created a single order — the customer paid once, the entitlement lapsed
    // after a month, and nothing ever charged again.
    const mandate: MandateMethod | null =
      method === 'upi' ? 'upi' : method === 'card' || method === 'cashfree' ? 'card' : null;

    if (mandate) {
      const subscription = await startSubscription({
        customer: {
          name: auth.name || settings.name || 'ThinkSharp member',
          email: auth.email,
          phone,
        },
        subscriptionTier: requestedTier,
        billingPeriod,
        method: mandate,
        country: settings.country,
      });
      if (subscription.authLink) {
        window.location.assign(subscription.authLink);
        return false;
      }
      throw new Error('Cashfree did not return an approval link. Please try again.');
    }

    // Crypto has no mandate concept — it stays a one-off charge for the period.
    const result = await startPayment({
      customer: {
        name: auth.name || settings.name || 'ThinkSharp member',
        email: auth.email,
        phone,
      },
      subscriptionTier: requestedTier,
      method,
      country: settings.country,
      billingPeriod,
    });

    if (result.kind === 'redirected') return false;

    if (!result.verification.isPaid) {
      throw new Error('This payment has not been confirmed yet. Complete the payment and try again.');
    }

    activatePaidPlan(result.verification, requestedTier);
    return true;
  };

  // Park the dot over the centre of the active tab. Measured, not calculated,
  // so it survives the lg: size change and any font/zoom setting.
  useEffect(() => {
    const move = () => {
      const dock = dockRef.current;
      const button = dockButtonRefs.current[tab];
      if (!dock || !button) return;
      const d = dock.getBoundingClientRect();
      const b = button.getBoundingClientRect();
      setDotX(b.left - d.left + b.width / 2 - 3);
    };
    move();
    window.addEventListener('resize', move);
    return () => window.removeEventListener('resize', move);
  }, [tab]);

  const daysUsed = Math.floor((Date.now() - firstUse) / 86400000);
  const trialDaysLeft = Math.max(0, TRIAL_DAYS - daysUsed);
  const hasPremium = settings.premium && (!settings.subscriptionExpiresAt || settings.subscriptionExpiresAt > Date.now());
  const activeTier: SubscriptionTier | null = hasPremium ? settings.subscriptionTier || 'ultimate' : null;
  const unabridgedAccess = activeTier === 'unabridged' && Boolean(settings.entitlementToken);
  const trialExpired = !hasPremium && trialDaysLeft <= 0;

  // A full storage quota must never take the whole app down mid-write.
  useEffect(() => {
    try {
      localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
    } catch {
      setPaymentNotice('This device is out of storage, so your latest entry could not be saved. Export your journal to free space.');
    }
  }, [entries]);

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Settings are non-critical; they fall back to defaults next launch.
    }
  }, [settings]);

  // Picks a payment back up after a redirect: Cashfree returns with an order id
  // in the URL, crypto returns to a bare URL so we fall back to the stored
  // pending order.
  useEffect(() => {
    if (!auth) return;

    const params = new URLSearchParams(window.location.search);

    // Returning from a mandate approval.
    const subscriptionId = params.get('ts_subscription_id') || readPendingSubscription();
    if (subscriptionId) {
      verifySubscription(subscriptionId)
        .then((verification) => {
          if (verification.isPaid) {
            clearPendingSubscription();
            activatePaidPlan(verification, verification.subscriptionTier || 'ultimate');
          } else if (verification.isExpired) {
            clearPendingSubscription();
            setPaymentNotice('That subscription was cancelled before it started.');
          } else {
            setPaymentNotice('Your bank is still approving the mandate. Access unlocks as soon as it does.');
          }
        })
        .catch(() => undefined)
        .finally(() => {
          if (window.location.search) window.history.replaceState({}, '', window.location.pathname);
        });
      return;
    }

    const cancelled = params.get('ts_payment') === 'cancelled';
    const urlOrderId =
      params.get('ts_order_id') || params.get('cashfree_order_id'); // legacy return URLs
    const pending = readPendingOrder();
    const orderId = urlOrderId || pending?.orderId || null;

    const cleanUrl = () => {
      if (window.location.search) window.history.replaceState({}, '', window.location.pathname);
    };

    if (cancelled) {
      clearPendingOrder();
      setPaymentNotice('That checkout was cancelled. No payment was taken.');
      cleanUrl();
      return;
    }

    if (!orderId) return;

    let active = true;

    verifyPaymentOrder(orderId)
      .then((verification) => {
        if (!active) return;
        if (verification.isPaid) {
          clearPendingOrder();
          activatePaidPlan(verification, pending?.tier || 'ultimate');
        } else if (verification.isExpired) {
          clearPendingOrder();
          setPaymentNotice('That checkout expired before it was paid. Please start a new one.');
        } else {
          // Crypto confirmations in particular can lag behind the redirect.
          setPaymentNotice('Your payment is still being confirmed. Keep this tab open — it will unlock automatically.');
          waitForPaidOrder(orderId, 30, 4000)
            .then((confirmed) => {
              if (!active) return;
              clearPendingOrder();
              activatePaidPlan(confirmed, pending?.tier || 'ultimate');
            })
            .catch((error) => {
              if (!active) return;
              setPaymentNotice(
                error instanceof Error ? error.message : 'We could not confirm that payment yet.',
              );
            });
        }
      })
      .catch(() => {
        if (active) setPaymentNotice('We could not verify that payment yet. Please try again shortly.');
      })
      .finally(cleanUrl);

    return () => {
      active = false;
    };
  }, [auth]);

  // Arriving from "Summarise my whole journal" on the entries screen.
  useEffect(() => {
    if (!summaryRequested) return;
    setSummaryRequested(false);
    if (hasPremium && !summaryLoading) runJournalSummary();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [summaryRequested]);

  // Someone who reinstalls, or signs in on a second device, should get back what
  // they already paid Google for without buying it again.
  useEffect(() => {
    if (!isPlayBillingPlatform() || !auth) return;
    let active = true;
    (async () => {
      await initPlayBilling();
      const owned = await restorePlayPurchases();
      if (!active || !owned.length) return;
      const best = owned.find((p) => p.tier === 'unabridged') || owned[0];
      try {
        const verification = hasVerificationBackend()
          ? await verifyPlayPurchase(best, auth.email)
          : await verifyWithPlayLocally(best);
        if (active && verification.isPaid) activatePaidPlan(verification, best.tier);
      } catch {
        // Offline, or Play unreachable. Leave existing state untouched.
      }
    })();
    return () => { active = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth]);

  const sorted = useMemo(
    () => [...entries].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
    [entries]
  );
  const streak = useMemo(() => getStreak(sorted), [sorted]);
  const totalWords = useMemo(() => entries.reduce((s, e) => s + e.words, 0), [entries]);
  const userXp = entries.length * 25 + totalWords + streak * 40;
  const draftWords = countWords(draft);
  const remainingFreeWords = Math.max(0, FREE_WORD_LIMIT - totalWords);
  const wordLimitBlocked = !hasPremium && draftWords > remainingFreeWords;
  const freeWordLimitReached = !hasPremium && remainingFreeWords === 0;
  const writingLocked = trialExpired || freeWordLimitReached;

  const saveEntry = () => {
    const drawing = captureDrawing();
    // A page of handwriting is a real entry even with no typed text.
    if ((!draft.trim() && !drawing) || !mood || writingLocked || wordLimitBlocked) {
      if (wordLimitBlocked) {
        setPaymentNotice('Your free 5,000-word limit has been reached. Upgrade for unlimited writing.');
      } else if (freeWordLimitReached) {
        setPaymentNotice('Your free 5,000-word limit has been reached. Upgrade for unlimited writing.');
      }
      return;
    }
    const entry: Entry = {
      id: createId(),
      prompt: PROMPTS[promptIndex],
      content: draft.trim(),
      mood,
      words: countWords(draft),
      createdAt: new Date().toISOString(),
      drawing,
    };
    setEntries((cur) => [entry, ...cur]);
    setDraft('');
    setMood(0);
    clearDrawing();
    setDrawMode(false);
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 2500);
  };

  const deleteEntry = (id: string) => {
    setEntries((cur) => cur.filter((e) => e.id !== id));
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(sorted, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'thinksharp-journal.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const plan = PRICING.find((p) => p.code === settings.country) ?? PRICING[0];

  // ---------- Views ----------

  const renderJournal = () => (
    <div className="animate-fadeIn">
      <div className="mt-10 text-center">
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-white drop-shadow-[0_1px_6px_rgba(0,0,0,0.95)]">Today&apos;s prompt</p>
        <h1 className="mx-auto mt-5 max-w-xl font-serif text-3xl leading-snug text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)] sm:text-4xl">
          {PROMPTS[promptIndex]}
        </h1>
        <button
          onClick={() => setPromptIndex((i) => (i + 1) % PROMPTS.length)}
          className="mx-auto mt-5 flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--chrome)] px-4 py-2 text-xs font-semibold text-[var(--text)] backdrop-blur-md transition hover:border-[var(--accent)]"
        >
          <Shuffle className="h-3.5 w-3.5" />
          Different prompt
        </button>
      </div>

      <div className="mt-10 flex items-center justify-center gap-3">
        {MOODS.map((m) => (
          <button
            key={m.value}
            onClick={() => setMood(m.value)}
            title={m.label}
            className={`flex h-12 w-12 items-center justify-center rounded-2xl text-2xl transition-all ${
              mood === m.value
                ? 'scale-110 bg-[var(--accent-soft)] ring-2 ring-[var(--accent)]'
                : 'bg-[var(--card)] opacity-60 hover:opacity-100 hover:scale-105'
            }`}
          >
            {m.emoji}
          </button>
        ))}
      </div>

      {/* Journal tools deliberately live between mood and the page, never over the writing surface. */}
      <div className="mt-5 flex items-center justify-center gap-2">
        <MusicPlayer />
        <button
          onClick={() => setWritingExpanded((current) => !current)}
          className={`flex h-11 items-center gap-2 rounded-2xl border px-3.5 text-sm font-semibold transition ${
            writingExpanded
              ? 'border-[var(--accent)] bg-[var(--accent)] text-white shadow-lg shadow-[var(--accent)]/20'
              : 'border-[var(--border)] bg-[var(--chrome)] text-[var(--text)] backdrop-blur-md hover:border-[var(--accent)]'
          }`}
          title={writingExpanded ? 'Use normal writing space' : 'Expand writing space'}
        >
          <OpenInFullRounded sx={{ fontSize: 19 }} />
          <span className="hidden sm:inline">{writingExpanded ? 'Compact' : 'Expand'}</span>
        </button>
        <button
          onClick={() => setDrawMode((current) => !current)}
          className={`flex h-11 items-center gap-2 rounded-2xl border px-3.5 text-sm font-semibold transition ${
            drawMode
              ? 'border-[var(--accent)] bg-[var(--accent)] text-white shadow-lg shadow-[var(--accent)]/20'
              : 'border-[var(--border)] bg-[var(--chrome)] text-[var(--text)] backdrop-blur-md hover:border-[var(--accent)]'
          }`}
          title="Write with a finger or stylus"
        >
          <DrawRounded sx={{ fontSize: 19 }} />
          <span className="hidden sm:inline">Draw</span>
        </button>
      </div>

      <div className="relative mt-8 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-2 shadow-xl backdrop-blur-md">
        {trialExpired && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 rounded-3xl bg-[var(--card)] backdrop-blur-sm">
            <Lock className="h-8 w-8 text-[#D4A088]" />
            <p className="max-w-xs text-center text-sm text-[var(--text)]">
              Your 3-day free trial has ended. Unlock Ultimate to keep journaling.
            </p>
            <button
              onClick={openPremiumFlow}
              className="rounded-2xl bg-gradient-to-r from-[#D4A088] to-[#A85E3C] px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-[#C08060]/15 transition hover:scale-105"
            >
              Unlock — {plan.price}
            </button>
          </div>
        )}
        {!trialExpired && freeWordLimitReached && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 rounded-3xl bg-[var(--card)] backdrop-blur-sm">
            <Lock className="h-8 w-8 text-[#D4A088]" />
            <p className="max-w-xs text-center text-sm text-[var(--text)]">
              You&apos;ve used all 5,000 free words. Upgrade for unlimited journaling.
            </p>
            <button
              onClick={openPremiumFlow}
              className="rounded-2xl bg-gradient-to-r from-[#D4A088] to-[#A85E3C] px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-[#C08060]/15 transition hover:scale-105"
            >
              Go Ultimate
            </button>
          </div>
        )}
        {/* Handwriting surface. It used to float over the bottom of the card
            with no way out of it and no way to keep what you drew — you could
            sketch, but the sketch was thrown away on save. Now it covers the
            card properly, has an explicit close, and the drawing is stored with
            the entry. */}
        {drawMode && (
          <div className="absolute inset-0 z-20 flex flex-col rounded-3xl bg-[var(--card2)] p-3">
            <div className="mb-2 flex items-center justify-between gap-2 px-1">
              <span className="text-[11px] font-medium text-[var(--muted)]">
                Write with a finger or stylus — it saves with your entry.
              </span>
              <div className="flex shrink-0 items-center gap-1.5">
                <button
                  onClick={clearDrawing}
                  className="rounded-lg border border-[var(--border)] px-2.5 py-1 text-[10px] font-semibold text-[var(--muted)] transition hover:text-[var(--text)]"
                >
                  Clear
                </button>
                <button
                  onClick={closeDrawing}
                  aria-label="Close handwriting"
                  className="flex h-7 w-7 items-center justify-center rounded-lg border border-[var(--border)] text-[var(--muted)] transition hover:border-[var(--accent)] hover:text-[var(--text)]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
            <canvas
              ref={drawCanvasRef}
              className="w-full flex-1 cursor-crosshair touch-none rounded-2xl border border-[var(--border)] bg-black/85"
              onPointerDown={startDrawing}
              onPointerMove={drawLine}
              onPointerUp={stopDrawing}
              onPointerCancel={stopDrawing}
            />
            <button
              onClick={closeDrawing}
              className="mt-2 rounded-2xl bg-[var(--accent)] py-2.5 text-sm font-bold text-white transition hover:opacity-90"
            >
              Done
            </button>
          </div>
        )}
        <textarea
          id="journal-textarea"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          className={`w-full resize-none rounded-2xl bg-transparent px-5 py-4 text-base leading-relaxed text-[var(--text)] placeholder-[var(--muted)] outline-none ${drawMode ? 'h-24 opacity-30' : ''}`}
          disabled={writingLocked}
          rows={drawMode ? 3 : writingExpanded ? 18 : 9}
          // Tablets have room for a real page; phones do not. Scale the writing
          // surface with the viewport instead of a fixed row count.
          style={drawMode ? undefined : { minHeight: 'clamp(210px, 32vh, 560px)' }}
          placeholder="Write your feelings out. No one is grading this…"
        />
        {pendingDrawing && !drawMode && (
          <button
            onClick={() => setDrawMode(true)}
            className="mx-4 mb-2 flex w-[calc(100%-2rem)] items-center gap-3 rounded-2xl border border-[var(--accent)]/35 bg-[var(--accent-soft)] p-2 text-left"
          >
            <img src={pendingDrawing} alt="" className="h-12 w-20 rounded-lg border border-[var(--border)] bg-black/85 object-contain" />
            <span className="text-xs font-semibold text-[var(--accent)]">
              Handwriting attached — tap to keep writing
            </span>
          </button>
        )}
        <div className="flex items-center justify-between px-4 pb-3">
          <span className={`text-xs ${wordLimitBlocked ? 'text-red-400' : 'text-[var(--muted)]'}`}>
            {draftWords} words{!mood && draft.trim() ? ' · pick a mood to save' : ''}
            {!hasPremium && ` · ${totalWords.toLocaleString()} / ${FREE_WORD_LIMIT.toLocaleString()} free words`}
            {hasPremium && ' · Unlimited writing'}
          </span>
          <button
            onClick={saveEntry}
            disabled={(!draft.trim() && !hasDrawingRef.current && !pendingDrawing) || !mood || writingLocked || wordLimitBlocked}
            className="flex items-center gap-2 rounded-2xl bg-[var(--accent)] px-6 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-40"
          >
            {justSaved ? (
              <>
                <Check className="h-4 w-4" />
                Saved
              </>
            ) : (
              <>
                <PenLine className="h-4 w-4" />
                Save entry
              </>
            )}
          </button>
        </div>
      </div>

      {!hasPremium && !freeWordLimitReached && trialDaysLeft > 0 && (
        <p className="mt-4 text-center text-xs text-[var(--muted)]">
          ✨ Free trial — <span className="font-semibold text-[#D4A088]">{trialDaysLeft} day{trialDaysLeft === 1 ? '' : 's'} left</span> · {remainingFreeWords.toLocaleString()} free words remaining
        </p>
      )}
    </div>
  );

  const renderLeaderboard = () => {
    const rows = [...BOTS, { name: settings.name || 'You', emoji: '✨', streak, xp: userXp, you: true }]
      .sort((a, b) => b.xp - a.xp);

    const board = leaderboardScope === 'friends' ? friends : rows;

    return (
      <div className="animate-fadeIn">
        <h2 className="font-serif text-3xl text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)]">Leaderboard</h2>
        <p className="mt-2 text-sm text-[var(--muted)]">
          Consistency beats intensity. XP = words written + streak bonus.
        </p>

        {/* Friends are a paid feature; Global is open to everyone so the tab
            still does something useful before you subscribe. */}
        <div className="mt-6 flex rounded-2xl border border-[var(--border)] bg-[var(--card2)] p-1">
          {([
            { id: 'global' as const, label: 'Global', icon: Globe2 },
            { id: 'friends' as const, label: 'Friends', icon: Users },
          ]).map((scope) => {
            const Icon = scope.icon;
            const active = leaderboardScope === scope.id;
            return (
              <button
                key={scope.id}
                onClick={() => setLeaderboardScope(scope.id)}
                className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition ${
                  active ? 'bg-[var(--accent)] text-white' : 'text-[var(--muted)] hover:text-[var(--text)]'
                }`}
              >
                <Icon className="h-4 w-4" />
                {scope.label}
                {scope.id === 'friends' && !hasPremium && <Lock className="h-3 w-3 opacity-70" />}
              </button>
            );
          })}
        </div>

        {leaderboardScope === 'friends' && !hasPremium ? (
          <div className="mt-6 rounded-3xl border border-[#C08060]/25 bg-[var(--card)] p-8 text-center backdrop-blur-md">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#D4A088] to-[#A85E3C]">
              <Users className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-4 font-serif text-xl text-[var(--text)]">Write alongside people you know</h3>
            <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[var(--muted)]">
              Add friends and see only their streaks — no strangers, no bots. Available on Ultimate and Unabridged.
            </p>
            <button
              onClick={openPremiumFlow}
              className="mt-5 rounded-2xl bg-gradient-to-r from-[#D4A088] to-[#A85E3C] px-6 py-3 text-sm font-bold text-white shadow-lg shadow-[#C08060]/15 transition hover:scale-105"
            >
              Unlock friends — {getTierPrice('ultimate', settings.country)} / mo
            </button>
          </div>
        ) : leaderboardScope === 'friends' && !friends.length ? (
          <div className="mt-6 rounded-3xl border border-dashed border-[var(--border)] bg-[var(--card)] p-8 text-center backdrop-blur-md">
            <p className="text-sm text-[var(--muted)]">
              No friends yet. Share your invite code and their streaks show up here.
            </p>
            <div className="mx-auto mt-4 w-fit rounded-2xl border border-[var(--accent)]/40 bg-[var(--accent-soft)] px-5 py-3 font-mono text-lg font-bold tracking-widest text-[var(--accent)]">
              {inviteCode}
            </div>
            <p className="mt-3 text-xs text-[var(--muted)]">
              Friend syncing needs the ThinkSharp backend — it activates once your account is online.
            </p>
          </div>
        ) : (
          <div className="mt-6 space-y-3">
            {board.map((row, index) => {
              const isYou = 'you' in row;
              return (
                <div
                  key={row.name}
                  className={`flex items-center gap-4 rounded-3xl border px-5 py-4 backdrop-blur-md transition ${
                    isYou
                      ? 'border-[var(--accent)] bg-[var(--card)] ring-1 ring-[var(--accent)]/40'
                      : 'border-[var(--border)] bg-[var(--card)]'
                  }`}
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                      index === 0 ? 'bg-[var(--accent)] text-white' : 'bg-[var(--card2)] text-[var(--muted)]'
                    }`}
                  >
                    {index + 1}
                  </span>
                  <span className="text-2xl">{row.emoji}</span>
                  <div className="flex-1">
                    <div className="text-sm font-semibold">
                      {row.name}
                      {isYou && <span className="ml-2 text-xs font-medium text-[var(--accent)]">(you)</span>}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1 text-xs text-[var(--muted)]">
                      <Flame className="h-3 w-3 text-[var(--accent)]" />
                      {row.streak} day streak
                    </div>
                  </div>
                  <span className="font-mono text-sm font-bold">{row.xp.toLocaleString()} XP</span>
                </div>
              );
            })}
          </div>
        )}

        {leaderboardScope === 'global' && (
          <p className="mt-4 text-center text-[11px] leading-4 text-[var(--muted)]">
            The global board is a demo set while ThinkSharp has no backend — these are not real people yet.
          </p>
        )}
      </div>
    );
  };

  const renderEntryReader = (entry: Entry) => {
    const moodMeta = MOODS.find((m) => m.value === entry.mood);
    return (
      <div className="animate-fadeIn">
        <button
          onClick={() => setOpenEntryId(null)}
          className="flex items-center gap-2 text-sm font-semibold text-[var(--muted)] transition hover:text-[var(--text)]"
        >
          <ChevronLeft className="h-4 w-4" />
          All entries
        </button>

        <article className="mt-5 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-6 backdrop-blur-md sm:p-8">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{moodMeta?.emoji}</span>
            <div>
              <div className="text-xs uppercase tracking-wide text-[var(--muted)]">
                {formatDate(entry.createdAt)} · {formatTime(entry.createdAt)}
              </div>
              <div className="mt-0.5 text-xs text-[var(--muted)]">
                {moodMeta?.label} · {entry.words} words
              </div>
            </div>
          </div>

          <h2 className="mt-6 font-serif text-2xl leading-snug text-[var(--text)]">{entry.prompt}</h2>

          {/* Serif, generous leading and a capped measure — this is the one
              screen whose job is reading, not scanning. */}
          {entry.content && (
            <p className="mt-5 whitespace-pre-wrap font-serif text-[17px] leading-8 text-[var(--text)]">
              {entry.content}
            </p>
          )}

          {entry.drawing && (
            <img
              src={entry.drawing}
              alt="Handwritten page"
              className="mt-5 w-full rounded-2xl border border-[var(--border)] bg-black/85"
            />
          )}

          <div className="mt-8 flex items-center justify-between border-t border-[var(--border)] pt-5">
            <span className="text-xs text-[var(--muted)]">
              {sorted.findIndex((e) => e.id === entry.id) + 1} of {sorted.length}
            </span>
            <button
              onClick={() => { deleteEntry(entry.id); setOpenEntryId(null); }}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-red-400 transition hover:bg-red-500/10"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Delete
            </button>
          </div>
        </article>

        <div className="mt-4 flex gap-2">
          {(() => {
            const i = sorted.findIndex((e) => e.id === entry.id);
            const newer = sorted[i - 1];
            const older = sorted[i + 1];
            return (
              <>
                <button
                  disabled={!newer}
                  onClick={() => newer && setOpenEntryId(newer.id)}
                  className="flex-1 rounded-2xl border border-[var(--border)] bg-[var(--card)] py-3 text-xs font-semibold text-[var(--muted)] transition hover:text-[var(--text)] disabled:opacity-30"
                >
                  Newer
                </button>
                <button
                  disabled={!older}
                  onClick={() => older && setOpenEntryId(older.id)}
                  className="flex-1 rounded-2xl border border-[var(--border)] bg-[var(--card)] py-3 text-xs font-semibold text-[var(--muted)] transition hover:text-[var(--text)] disabled:opacity-30"
                >
                  Older
                </button>
              </>
            );
          })()}
        </div>
      </div>
    );
  };

  const renderEntries = () => {
    const open = openEntryId ? sorted.find((e) => e.id === openEntryId) : null;
    if (open) return renderEntryReader(open);

    const query = entrySearch.trim().toLowerCase();
    const matches = query
      ? sorted.filter((e) => `${e.prompt} ${e.content}`.toLowerCase().includes(query))
      : sorted;

    // Group by calendar day so the list reads as a timeline, not a feed.
    const groups: { day: string; label: string; items: Entry[] }[] = [];
    matches.forEach((entry) => {
      const day = new Date(entry.createdAt).toISOString().slice(0, 10);
      const last = groups[groups.length - 1];
      if (last && last.day === day) last.items.push(entry);
      else groups.push({ day, label: formatDate(entry.createdAt), items: [entry] });
    });

    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

    return (
      <div className="animate-fadeIn">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-serif text-3xl text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)]">Past entries</h2>
            <p className="mt-2 text-sm text-[var(--muted)]">
              {entries.length} entr{entries.length === 1 ? 'y' : 'ies'} · {totalWords.toLocaleString()} words
            </p>
          </div>
          {entries.length > 0 && (
            <button
              onClick={exportData}
              className="flex shrink-0 items-center gap-2 rounded-2xl border border-[var(--border)] px-4 py-2 text-xs font-medium text-[var(--muted)] transition hover:border-[var(--accent)] hover:text-[var(--text)]"
            >
              <Download className="h-3.5 w-3.5" />
              Export
            </button>
          )}
        </div>

        {entries.length > 0 && (
          <>
            <div className="relative mt-6">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted)]" />
              <input
                value={entrySearch}
                onChange={(e) => setEntrySearch(e.target.value)}
                placeholder="Search everything you have written…"
                className="w-full rounded-2xl border border-[var(--border)] bg-[var(--card)] py-3 pl-11 pr-4 text-sm text-[var(--text)] outline-none backdrop-blur-md transition placeholder:text-[var(--muted)] focus:border-[var(--accent)]"
              />
            </div>

            {/* Summarise the whole journal, not just what is on screen. */}
            <button
              onClick={() => { setTab('analysis'); setSummaryRequested(true); }}
              className="mt-3 flex w-full items-center justify-between gap-3 rounded-2xl border border-[var(--accent)]/35 bg-[var(--accent-soft)] px-5 py-4 text-left transition hover:border-[var(--accent)]"
            >
              <span>
                <span className="flex items-center gap-2 text-sm font-bold text-[var(--accent)]">
                  <Sparkles className="h-4 w-4" />
                  Summarise my whole journal
                </span>
                <span className="mt-1 block text-xs leading-5 text-[var(--muted)]">
                  All {entries.length} entries and {totalWords.toLocaleString()} words, condensed to at most 20 points.
                </span>
              </span>
              <ChevronRight className="h-5 w-5 shrink-0 text-[var(--accent)]" />
            </button>
          </>
        )}

        <div className="mt-6 space-y-6">
          {!sorted.length && (
            <div className="rounded-3xl border border-dashed border-[var(--border)] bg-[var(--card)] p-10 text-center text-sm text-[var(--muted)] backdrop-blur-md">
              Nothing here yet. Your saved entries will live on this shelf.
            </div>
          )}
          {!!sorted.length && !matches.length && (
            <div className="rounded-3xl border border-dashed border-[var(--border)] bg-[var(--card)] p-10 text-center text-sm text-[var(--muted)] backdrop-blur-md">
              Nothing matches “{entrySearch.trim()}”.
            </div>
          )}

          {groups.map((group) => (
            <div key={group.day}>
              <div className="sticky top-[76px] z-10 -mx-1 mb-2 px-1">
                <span className="inline-block rounded-full bg-[var(--chrome)] px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-[var(--muted)] backdrop-blur-md">
                  {group.day === today ? 'Today' : group.day === yesterday ? 'Yesterday' : group.label}
                </span>
              </div>
              <div className="space-y-2">
                {group.items.map((entry) => {
                  const moodMeta = MOODS.find((m) => m.value === entry.mood);
                  return (
                    <button
                      key={entry.id}
                      onClick={() => setOpenEntryId(entry.id)}
                      className="flex w-full items-center gap-4 rounded-3xl border border-[var(--border)] bg-[var(--card)] px-5 py-4 text-left backdrop-blur-md transition hover:border-[var(--accent)]"
                    >
                      <span className="text-2xl">{moodMeta?.emoji}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-[var(--text)]">{entry.prompt}</span>
                        {/* One line of the entry itself, so the list is
                            scannable without opening anything. */}
                        <span className="mt-0.5 block truncate text-xs text-[var(--muted)]">
                          {entry.content.replace(/\s+/g, ' ').slice(0, 90)}
                        </span>
                        <span className="mt-1 block text-[11px] text-[var(--muted)]">
                          {formatTime(entry.createdAt)} · {entry.words} words
                        </span>
                      </span>
                      <ChevronRight className="h-4 w-4 shrink-0 text-[var(--muted)]" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderAnalysis = () => {
    const depth = hasPremium ? 100 : 10;
    const lastN = sorted.slice(0, depth);
    const avgMood = lastN.length ? lastN.reduce((s, e) => s + e.mood, 0) / lastN.length : 0;
    const theme = inferTheme(lastN);
    const words = topWords(lastN);
    const chartEntries = sorted.slice(0, 10);

    return (
      <div className="animate-fadeIn">
        <div>
          <div>
            <h2 className="font-serif text-3xl text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)]">Analysis till now</h2>
            <p className="mt-2 text-sm text-[var(--muted)]">
              {hasPremium
                ? `${activeTier === 'unabridged' ? 'Unabridged' : 'Ultimate'}: reading ${lastN.length === entries.length ? `all ${lastN.length}` : `your most recent ${lastN.length}`} ${lastN.length === 1 ? 'entry' : 'entries'}.`
                : `Free plan looks at your last 10 entries. Ultimate reads your last 100.`}
            </p>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:gap-4">
          {[
            { label: 'Entries', value: String(entries.length) },
            { label: 'Streak', value: `${streak}d` },
            { label: 'Words', value: totalWords.toLocaleString() },
            { label: 'Avg mood', value: avgMood ? avgMood.toFixed(1) : '—' },
          ].map((stat) => (
            <div key={stat.label} className="rounded-3xl border border-[var(--border)] bg-[var(--card)] p-5 text-center backdrop-blur-md">
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="mt-1 text-xs uppercase tracking-wide text-[var(--muted)]">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-6 backdrop-blur-md">
          <div className="text-sm font-semibold">Mood — last 10 entries</div>
          {chartEntries.length ? (
            /* The bar used to take height in %, but its parent column had no
               height of its own, so every bar resolved to 0px and the chart
               drew nothing at all. Fixed track height + px bars instead. */
            <div className="mt-5 flex items-end justify-center gap-3">
              {[...chartEntries].reverse().map((entry) => {
                const meta = MOODS.find((m) => m.value === entry.mood);
                return (
                  <div key={entry.id} className="flex flex-col items-center gap-2">
                    <div className="flex h-24 items-end" title={`${meta?.label} · ${formatDate(entry.createdAt)}`}>
                      <div
                        className="w-6 rounded-t-lg bg-[var(--accent)] transition-all"
                        style={{ height: `${8 + (entry.mood / 5) * 88}px`, opacity: 0.35 + entry.mood * 0.13 }}
                      />
                    </div>
                    <span className="text-sm">{meta?.emoji}</span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="mt-3 text-sm text-[var(--muted)]">Write a few entries to see your mood curve.</p>
          )}
        </div>

        <div className="mt-4 rounded-3xl border border-[var(--border)] bg-[var(--card)] p-6 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">
              Patterns in your writing
              {hasPremium && <span className="ml-2 rounded-full bg-[#C08060]/10 px-2 py-0.5 text-[10px] font-bold text-[#D4A088]">{activeTier === 'unabridged' ? 'UNABRIDGED' : 'ULTIMATE'}</span>}
            </div>
            {/* Named honestly: this section is computed on the device from your
                own text. Nothing is sent anywhere. Fable 5 below is the only
                part of ThinkSharp that calls a language model. */}
            <span className="rounded-full bg-[var(--accent-soft)] px-3 py-1 text-xs font-semibold text-[var(--accent)]">
              On this device
            </span>
          </div>

          {lastN.length ? (
            <div className="mt-4 space-y-3 text-sm leading-6">
              <p>
                <span className="text-[var(--muted)]">Theme:</span> <strong>{theme}</strong>
              </p>
              <p>
                <span className="text-[var(--muted)]">Recurring words:</span>{' '}
                {words.length ? words.join(', ') : 'not enough writing yet'}
              </p>
              <div className="rounded-2xl bg-[var(--card2)] p-4">
                <div className="text-xs font-semibold uppercase tracking-wide text-[var(--muted)]">Suggested next prompt</div>
                <p className="mt-1.5 font-serif text-base">{suggestPrompt(avgMood)}</p>
              </div>

              {/* The whole-journal summary: a real model reading everything,
                  rather than word counts. One model per tier, picked on the
                  server — see netlify/functions/journal-summary.mjs. */}
              {hasPremium && (
                <div className="rounded-2xl border border-[var(--accent)]/35 bg-[var(--card2)] p-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-sm font-bold text-[var(--text)]">
                        <Sparkles className="h-4 w-4 text-[var(--accent)]" />
                        Your journal, condensed
                      </div>
                      <p className="mt-1 text-xs leading-5 text-[var(--muted)]">
                        Reads your entries and reduces them to at most 20 points.
                      </p>
                    </div>
                    <button
                      onClick={runJournalSummary}
                      disabled={!entries.length || summaryLoading}
                      className="shrink-0 rounded-xl bg-[var(--accent)] px-4 py-2.5 text-xs font-bold text-white transition hover:opacity-90 disabled:opacity-50"
                    >
                      {summaryLoading ? 'Reading your journal…' : summary ? 'Refresh summary' : 'Summarise'}
                    </button>
                  </div>

                  {summaryError && (
                    <p className="mt-3 rounded-xl bg-red-500/10 px-3 py-2 text-xs text-red-300">{summaryError}</p>
                  )}

                  {summary && (
                    <div className="mt-4 space-y-3">
                      {summary.arc && (
                        <p className="rounded-xl border border-[var(--accent)]/25 bg-[var(--accent-soft)] px-3 py-2.5 font-serif text-sm leading-6 text-[var(--text)]">
                          {summary.arc}
                        </p>
                      )}
                      <ol className="space-y-2.5">
                        {summary.points.map((point, index) => (
                          <li key={point.heading + index} className="flex gap-3">
                            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[var(--accent-soft)] text-[10px] font-bold text-[var(--accent)]">
                              {index + 1}
                            </span>
                            <span>
                              <span className="block text-sm font-semibold text-[var(--text)]">{point.heading}</span>
                              <span className="mt-0.5 block text-xs leading-5 text-[var(--muted)]">{point.detail}</span>
                            </span>
                          </li>
                        ))}
                      </ol>
                      {/* Say exactly what was read. Claiming "read in full"
                          while silently dropping most of a long journal is
                          the kind of thing that destroys trust in a paid
                          feature the moment someone notices. */}
                      <p className="text-[11px] leading-4 text-[var(--muted)]">
                        Read {summary.entriesAnalyzed} of {entries.length}{' '}
                        {entries.length === 1 ? 'entry' : 'entries'}
                        {summary.wordsAnalyzed ? ` (~${summary.wordsAnalyzed.toLocaleString()} words)` : ''}
                        {summary.passes > 1 ? ', summarised in two passes' : ''} ·{' '}
                        {summary.tier === 'unabridged' ? 'Unabridged' : 'Ultimate'}
                        {summary.trimmed ? ' · oldest entries fell outside this plan’s limit' : ''}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {hasPremium ? (
                <div className="rounded-2xl border border-[#C08060]/20 bg-[#C08060]/5 p-4">
                  <div className="text-xs font-semibold uppercase tracking-wide text-[#D4A088]">
                    Questions built from your last {Math.min(100, lastN.length)} entries
                  </div>
                  <div className="mt-2 space-y-2">
                    {historyQuestions(lastN).map((q) => (
                      <p key={q} className="font-serif text-base leading-6">— {q}</p>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex w-full items-center justify-between rounded-2xl border border-[#C08060]/20 bg-[#C08060]/5 p-4 text-left">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-[#D4A088]">
                      <Lock className="h-4 w-4" />
                      Personalized questions from your last 100 entries
                    </div>
                    <p className="mt-1 text-xs text-[var(--muted)]">
                      Ultimate asks you questions based on what you actually keep writing about.
                    </p>
                  </div>
                  <Crown className="h-5 w-5 shrink-0 text-[#D4A088]" />
                </div>
              )}

              {unabridgedAccess && (
                <div className="rounded-2xl border border-[var(--accent)]/35 bg-[var(--card2)] p-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="text-sm font-bold text-white">Fable 5 deep reflection</div>
                      <p className="mt-1 text-xs leading-5 text-[var(--muted)]">Run a long-context reflection across your latest {Math.min(100, lastN.length)} entries.</p>
                    </div>
                    <button
                      onClick={() => runFable5Reflection(lastN)}
                      disabled={!lastN.length || fableLoading}
                      className="rounded-xl bg-[var(--accent)] px-4 py-2.5 text-xs font-bold text-white transition hover:opacity-90 disabled:opacity-50"
                    >
                      {fableLoading ? 'Fable 5 is thinking…' : 'Run Fable 5'}
                    </button>
                  </div>
                  {fableError && <p className="mt-3 rounded-xl bg-red-500/10 px-3 py-2 text-xs text-red-300">{fableError}</p>}
                  {fableReflection && <div className="mt-3 whitespace-pre-wrap rounded-xl border border-[var(--border)] bg-[var(--card)] p-3 text-sm leading-6 text-[var(--text)]">{fableReflection}</div>}
                </div>
              )}
            </div>
          ) : (
            <p className="mt-3 text-sm text-[var(--muted)]">Once you have entries, your reflection appears here.</p>
          )}
        </div>
      </div>
    );
  };

  const renderSettings = () => (
    <div className="animate-fadeIn">
      <div>
        <h2 className="font-serif text-3xl text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)]">Settings</h2>
      </div>

      <div className="mt-8 space-y-4">
        {/* Account stays optional until the user starts a paid subscription. */}
        {auth ? (
          <div className="flex items-center justify-between rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[var(--accent)]/15 text-base font-bold text-[var(--accent)]">
                {(auth.name || auth.email)[0]?.toUpperCase()}
              </div>
              <div>
                <div className="text-sm font-semibold">{auth.name}</div>
                <div className="mt-0.5 text-xs text-[var(--muted)]">
                  {auth.email}
                </div>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 rounded-2xl border border-[var(--border)] bg-[var(--card2)] px-4 py-2.5 text-sm font-medium text-[var(--muted)] transition hover:border-red-500/30 hover:text-red-400"
            >
              <LogOut className="h-4 w-4" />
              Sign out
            </button>
          </div>
        ) : (
          <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
            <div className="text-sm font-semibold">Guest mode</div>
            <p className="mt-1 text-xs leading-5 text-[var(--muted)]">
              You can journal without an account. We only ask for an account when you decide to purchase Ultimate.
            </p>
          </div>
        )}

        <div className="flex items-center justify-between rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold">
              Plan
              {hasPremium && <Crown className="h-4 w-4 text-[#D4A088]" />}
            </div>
            <div className="mt-0.5 text-xs text-[var(--muted)]">
              {hasPremium
                ? `${activeTier === 'unabridged' ? 'Unabridged' : 'Ultimate'} active · ${plan.flag} ${activeTier === 'unabridged' ? getTierPrice('unabridged', settings.country) + ' / mo' : plan.price}`
                : trialDaysLeft > 0
                ? `Free trial · ${trialDaysLeft} day${trialDaysLeft === 1 ? '' : 's'} left · ${totalWords.toLocaleString()} / ${FREE_WORD_LIMIT.toLocaleString()} words used`
                : `Trial ended · ${totalWords.toLocaleString()} / ${FREE_WORD_LIMIT.toLocaleString()} free words used`}
            </div>
          </div>
          <span className="rounded-full border border-[var(--border)] bg-[var(--card2)] px-3 py-1.5 text-xs font-semibold text-[var(--muted)]">
            {hasPremium ? 'Unlimited writing' : '5,000-word free limit'}
          </span>
        </div>

        <div className="flex items-center justify-between rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <div>
            <div className="text-sm font-semibold">Appearance</div>
            <div className="mt-0.5 text-xs text-[var(--muted)]">{settings.theme === 'dark' ? 'Dark mode' : 'Light mode'}</div>
          </div>
          <button
            onClick={() => setSettings((current) => ({ ...current, theme: current.theme === 'dark' ? 'light' : 'dark' }))}
            className="flex items-center gap-2 rounded-2xl bg-[var(--accent-soft)] px-4 py-2.5 text-sm font-semibold text-[var(--accent)] transition hover:opacity-80"
          >
            {settings.theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            {settings.theme === 'dark' ? 'Use light mode' : 'Use dark mode'}
          </button>
        </div>

        {/* The "Go fullscreen" card lived here. ThinkSharp ships as an Android
            app, where the WebView is already fullscreen and the Fullscreen API
            is a no-op — so the button promised something it could never do. */}

        <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <div className="text-sm font-semibold">Display name</div>
          <input
            value={settings.name}
            onChange={(e) => setSettings((s) => ({ ...s, name: e.target.value }))}
            className="mt-3 w-full rounded-2xl border border-[var(--border)] bg-[var(--card2)] px-4 py-3 text-sm outline-none transition focus:border-[var(--accent)]"
            placeholder="How should the leaderboard call you?"
          />
        </div>

        {/* The "Reflection model" picker that used to live here offered
            GLM-4-Flash / DeepSeek-V3 / Qwen, with per-million prices and a
            live cost readout. None of them were ever called — the selection
            changed a label and a fabricated cost figure and nothing else.
            Removed rather than left in as decoration. */}
        <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <div className="text-sm font-semibold">How your journal is analysed</div>
          <p className="mt-1 text-xs leading-5 text-[var(--muted)]">
            Patterns, moods and recurring words are worked out on this device, from your own text.
            Your entries never leave your phone.
            {activeTier === 'unabridged'
              ? ' Fable 5 reflections are the one exception — those entries are sent to Anthropic to be read, and only when you tap Run Fable 5.'
              : ' The Fable 5 plan adds deep reflections written by a language model, which does send those entries off the device.'}
          </p>
        </div>

        <div className="flex flex-wrap gap-3 rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <button
            onClick={exportData}
            disabled={!entries.length}
            className="flex items-center gap-2 rounded-2xl border border-[var(--border)] px-4 py-2.5 text-sm font-medium transition hover:border-[var(--accent)] disabled:opacity-40"
          >
            <Download className="h-4 w-4" />
            Export journal
          </button>
          <button
            onClick={() => setEntries([])}
            disabled={!entries.length}
            className="flex items-center gap-2 rounded-2xl border border-red-500/30 px-4 py-2.5 text-sm font-medium text-red-400 transition hover:bg-red-500/10 disabled:opacity-40"
          >
            <Trash2 className="h-4 w-4" />
            Delete all entries
          </button>
        </div>

        {/* Google Play requires account deletion to be reachable in-app as well
            as at a public URL, and a privacy policy link is mandatory for the
            listing. */}
        <div className="rounded-3xl border border-[var(--border)] bg-[var(--card)] px-6 py-5 backdrop-blur-md">
          <div className="text-sm font-semibold">Privacy &amp; legal</div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {[
              { href: '/legal/privacy.html', label: 'Privacy policy' },
              { href: '/legal/terms.html', label: 'Terms of service' },
              { href: '/legal/refund.html', label: 'Refunds & cancellation' },
              { href: '/legal/delete-account.html', label: 'Delete my account' },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noreferrer"
                className="rounded-2xl border border-[var(--border)] bg-[var(--card2)] px-4 py-3 text-sm font-medium transition hover:border-[var(--accent)]"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <p className="px-2 text-center text-xs leading-5 text-[var(--muted)]">
          ThinkSharp is local-first — your journal stays on this device unless you ask for a summary.
        </p>
      </div>
    </div>
  );

  // ---------- Dock ----------

  const dockItems: { id: Tab; icon: ElementType; label: string }[] = [
    { id: 'journal', icon: EditRounded, label: 'Journal' },
    { id: 'leaderboard', icon: EmojiEventsRounded, label: 'Leaderboard' },
    { id: 'entries', icon: HistoryRounded, label: 'Past Entries' },
    { id: 'analysis', icon: InsightsRounded, label: 'Analysis' },
    { id: 'settings', icon: SettingsRounded, label: 'Settings' },
  ];

  return (
    <div
      style={settings.theme === 'dark' ? DARK_VARS : LIGHT_VARS}
      /* No background colour here. NatureBackground sits at `fixed inset-0
         -z-10`, and a negative-z-index child paints BELOW its parent's own
         background — so an opaque colour on this element hides the photos
         completely. Overscroll is covered by html/body in index.css instead. */
      className="min-h-screen text-[var(--text)]"
    >
      {/* Rotating nature backgrounds (brighter overlay) */}
      <NatureBackground
        /* The overlay was heavy enough that darker scenes (misty forest, night
           stag) crushed to near-black on card-dense screens, so the photo read
           as "not loaded". Cards already carry their own 90% backdrop for
           legibility, so the global scrim can be much lighter. */
        /* Light enough that the photograph actually reads as a photograph.
           Cards carry their own 90% backdrop, so legibility does not depend on
           this layer — it only needs to stop the very brightest scenes from
           fighting the dock. */
        /* Dark mode veils the scene slightly darker; light mode veils it
           LIGHTER. Using a dark scrim in both was why light mode looked like a
           black screen with a cream header stuck on top — the theme changed
           the chrome but never the backdrop. */
        overlay={settings.theme === 'dark'
          ? 'from-[#16110D]/5 via-[#16110D]/15 to-[#16110D]/35'
          : 'from-[#FBF6F0]/70 via-[#FBF6F0]/78 to-[#FBF6F0]/88'}
        /* The scene caption is decorative and sat directly on top of the
           textarea, obscuring the first seconds of whatever you typed.
           Never show it on the screen whose whole job is writing. */
        // Never over a surface whose job is words: writing (journal) or
        // reading (entries + the single-entry reader).
        showLabel={tab !== 'journal' && tab !== 'entries'}
      />

      {/* Global header: big logo + always-on-top premium button */}
      <header className="sticky top-0 z-50 border-b border-[var(--border)] bg-[var(--chrome)] backdrop-blur-xl">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-5 py-3 lg:max-w-5xl lg:px-8">
          <button onClick={() => setTab('journal')} className="flex items-center gap-3">
            <img
              src="/images/thinksharp-logo.png"
              alt="ThinkSharp logo"
              className="ts-logo h-14 w-14 rounded-2xl shadow-lg ring-1 ring-[var(--accent)]/20 sm:h-16 sm:w-16"
            />
            <div className="text-left">
              <div className="font-serif text-2xl font-semibold tracking-tight text-[var(--text)] sm:text-3xl">
                Think<span className="text-[var(--accent)]">Sharp</span>
              </div>
              <div className="hidden text-[11px] tracking-wide text-[var(--muted)] sm:block">
                Journal at the edge of the universe
              </div>
            </div>
          </button>

          <div className="flex items-center gap-2.5">
            {streak > 0 && (
              <span className="hidden items-center gap-1 rounded-full bg-[var(--accent-soft)] px-2.5 py-1.5 text-xs font-semibold text-[var(--accent)] sm:flex">
                <Flame className="h-3.5 w-3.5" />
                {streak}
              </span>
            )}
            <button
              onClick={openPremiumFlow}
              className={`flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition hover:scale-105 ${
                hasPremium
                  ? 'border border-[#C08060]/25 bg-[#C08060]/8 text-[#D4A088]'
                  : 'bg-gradient-to-r from-[#D4A088] to-[#A85E3C] text-white shadow-lg shadow-[#C08060]/12'
              }`}
            >
              <Crown className="h-4 w-4" />
              <span className="hidden sm:inline">{hasPremium ? (activeTier === 'unabridged' ? 'Unabridged' : 'Ultimate') : 'Go Ultimate'}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-2xl px-5 pb-56 pt-4 sm:pt-6 lg:max-w-5xl lg:px-8">
        {paymentNotice && (
          <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--card)] px-4 py-3 text-sm text-[var(--text)] backdrop-blur-md">
            <span>{paymentNotice}</span>
            <button onClick={() => setPaymentNotice('')} className="shrink-0 text-xs font-semibold text-[#D4A088]">Dismiss</button>
          </div>
        )}
        {tab === 'journal' && renderJournal()}
        {tab === 'leaderboard' && renderLeaderboard()}
        {tab === 'entries' && renderEntries()}
        {tab === 'analysis' && renderAnalysis()}
        {tab === 'settings' && renderSettings()}
      </main>

      <SubscriptionAuthModal
        open={subscriptionAuthOpen}
        onClose={() => {
          setSubscriptionAuthOpen(false);
          setContinueToCheckout(false);
        }}
        onAuthenticated={handleAuth}
      />

      {auth && <PremiumModal
        open={premiumOpen}
        onClose={() => setPremiumOpen(false)}
        activeTier={activeTier}
        country={settings.country}
        setCountry={(code) => setSettings((s) => ({ ...s, country: code }))}
        customer={{ name: auth.name, email: auth.email }}
        onPay={handlePayment}
        trialDaysLeft={trialDaysLeft}
      />}

      {/* Dock.
          The magnify used to be hover-only, which meant it simply did not exist
          on a phone. Replaced with two things that work on touch: a single dot
          that slides to whichever tab is selected, and a squash-then-pop on the
          icon you press. The dot is positioned from the real measured button
          offset rather than computed from padding and gaps, so it stays correct
          at every breakpoint. */}
      <nav className="fixed inset-x-0 bottom-5 z-50 flex justify-center px-4">
        <div ref={dockRef} className="relative flex items-end gap-1 rounded-[26px] border border-[var(--border)] bg-[var(--chrome)] px-3 py-2.5 shadow-2xl backdrop-blur-xl sm:gap-2">
          <span
            aria-hidden
            className="pointer-events-none absolute top-1 h-1.5 w-1.5 rounded-full bg-[var(--accent)] transition-transform duration-300 ease-out"
            style={{ transform: `translateX(${dotX}px)`, left: 0 }}
          />
          {dockItems.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                ref={(el) => { dockButtonRefs.current[item.id] = el; }}
                onClick={() => { setTab(item.id); setTappedTab(item.id); }}
                onAnimationEnd={() => setTappedTab(null)}
                title={item.label}
                aria-label={item.label}
                aria-current={active ? 'page' : undefined}
                className="group relative flex flex-col items-center"
              >
                <span className="pointer-events-none absolute -top-9 whitespace-nowrap rounded-lg bg-[var(--card2)] px-2.5 py-1 text-[11px] font-medium text-[var(--text)] opacity-0 shadow-lg transition-all duration-200 group-hover:opacity-100">
                  {item.label}
                </span>
                <span
                  className={`flex h-12 w-12 items-center justify-center rounded-2xl transition-colors duration-200 lg:h-14 lg:w-14 ${
                    tappedTab === item.id ? 'ts-dock-tap' : ''
                  } ${
                    active
                      ? 'bg-[var(--accent)] text-white shadow-lg'
                      : 'border border-[var(--border)] bg-[var(--card2)] text-[var(--muted)] group-hover:border-[var(--accent)] group-hover:text-[var(--text)]'
                  }`}
                >
                  <Icon sx={{ fontSize: 25 }} />
                </span>
                <span className="mt-1.5 h-1 w-1" />
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
