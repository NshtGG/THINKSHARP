import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bitcoin,
  Check,
  CreditCard,
  Crown,
  Globe,
  Loader2,
  Phone,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Star,
  Wallet,
  X,
} from 'lucide-react';
import { isPlayBillingPlatform } from '../utils/playBilling';
import {
  availableMethods,
  BILLING_PERIODS,
  fetchPaymentsStatus,
  type BillingPeriod,
  type PaymentsStatus,
  type SubscriptionTier,
  chargeCurrency,
  defaultMethod,
  isMethodAvailable,
  LOCAL_CURRENCY,
  PAYMENT_METHODS,
  type PaymentMethod,
} from '../utils/payments';

export type { SubscriptionTier } from '../utils/payments';

export type CountryPrice = {
  code: string;
  flag: string;
  name: string;
  price: string;
  usd: number;
};

export const PRICING: CountryPrice[] = [
  { code: 'US', flag: '🇺🇸', name: 'United States', price: '$20 / mo', usd: 20 },
  { code: 'GB', flag: '🇬🇧', name: 'United Kingdom', price: '£16 / mo', usd: 20 },
  { code: 'EU', flag: '🇪🇺', name: 'Eurozone', price: '€18 / mo', usd: 19.5 },
  { code: 'CA', flag: '🇨🇦', name: 'Canada', price: 'C$26 / mo', usd: 19 },
  { code: 'AU', flag: '🇦🇺', name: 'Australia', price: 'A$29 / mo', usd: 19 },
  { code: 'IN', flag: '🇮🇳', name: 'India', price: '₹2,000 / mo', usd: 24 },
  { code: 'BR', flag: '🇧🇷', name: 'Brazil', price: 'R$49 / mo', usd: 8.6 },
  { code: 'JP', flag: '🇯🇵', name: 'Japan', price: '¥2,400 / mo', usd: 16 },
  { code: 'CN', flag: '🇨🇳', name: 'China', price: '¥68 / mo', usd: 9.4 },
  { code: 'MX', flag: '🇲🇽', name: 'Mexico', price: 'MX$199 / mo', usd: 10.5 },
  { code: 'NG', flag: '🇳🇬', name: 'Nigeria', price: '₦9,900 / mo', usd: 6.2 },
  { code: 'ID', flag: '🇮🇩', name: 'Indonesia', price: 'Rp159,000 / mo', usd: 9.8 },
  { code: 'PH', flag: '🇵🇭', name: 'Philippines', price: '₱549 / mo', usd: 9.5 },
  { code: 'PK', flag: '🇵🇰', name: 'Pakistan', price: '₨1,900 / mo', usd: 6.8 },
  { code: 'VN', flag: '🇻🇳', name: 'Vietnam', price: '₫249,000 / mo', usd: 9.8 },
  { code: 'TR', flag: '🇹🇷', name: 'Türkiye', price: '₺349 / mo', usd: 10.2 },
];

export function detectCountry(): string {
  try {
    const region = (navigator.language || 'en-US').split('-')[1]?.toUpperCase();
    const eurozone = ['DE', 'FR', 'ES', 'IT', 'NL', 'PT', 'IE', 'AT', 'BE', 'FI', 'GR'];
    if (eurozone.includes(region || '')) return 'EU';
    return PRICING.some((price) => price.code === region) ? region! : 'US';
  } catch {
    return 'US';
  }
}

/** Unabridged is ten times Ultimate in every market. */
const UNABRIDGED_MULTIPLIER = 10;

function marketFor(country: string) {
  return PRICING.find((price) => price.code === country) ?? PRICING[0];
}

/** Splits "₹2,000 / mo" into its symbol and numeric parts. */
function parsePrice(display: string): { symbol: string; value: number } {
  const numeric = Number(display.replace(/[^0-9.]/g, ''));
  const symbol = display.replace(/[0-9.,]/g, '').replace('/ mo', '').trim();
  return { symbol, value: numeric };
}

function formatMoney(symbol: string, value: number, country: string) {
  const rounded = Math.round(value);
  return `${symbol}${rounded.toLocaleString(country === 'IN' ? 'en-IN' : 'en-US')}`;
}

/** Per-month price for a tier at a given billing period. */
export function getMonthlyPrice(tier: SubscriptionTier, country: string, period: BillingPeriod) {
  const { symbol, value } = parsePrice(marketFor(country).price);
  const base = tier === 'unabridged' ? value * UNABRIDGED_MULTIPLIER : value;
  const rate = BILLING_PERIODS.find((p) => p.id === period)?.rate ?? 1;
  return formatMoney(symbol, base * rate, country);
}

/** What is actually charged at checkout for the whole period. */
export function getTotalPrice(tier: SubscriptionTier, country: string, period: BillingPeriod) {
  const { symbol, value } = parsePrice(marketFor(country).price);
  const meta = BILLING_PERIODS.find((p) => p.id === period) ?? BILLING_PERIODS[0];
  const base = tier === 'unabridged' ? value * UNABRIDGED_MULTIPLIER : value;
  return formatMoney(symbol, base * meta.rate * meta.months, country);
}

export function getTierPrice(tier: SubscriptionTier, country: string) {
  return `${getMonthlyPrice(tier, country, 'monthly')} / mo`;
}

/** The USD equivalent, used whenever a charge cannot settle in local currency. */
export function getUsdPrice(tier: SubscriptionTier, country: string) {
  const market = marketFor(country);
  return tier === 'unabridged' ? market.usd * UNABRIDGED_MULTIPLIER : market.usd;
}

/**
 * What the customer will actually be debited, which is not always the list
 * price: crypto settles in USD, and so do markets Cashfree cannot bill locally.
 */
export function getChargePrice(
  tier: SubscriptionTier,
  country: string,
  method: PaymentMethod,
  period: BillingPeriod = 'monthly',
) {
  const currency = chargeCurrency(tier, country, method);
  const local = LOCAL_CURRENCY[country] || 'USD';
  const meta = BILLING_PERIODS.find((p) => p.id === period) ?? BILLING_PERIODS[0];

  if (currency === local) {
    return { display: getTotalPrice(tier, country, period), converted: false };
  }
  const usd = Math.round(getUsdPrice(tier, country) * meta.rate * meta.months);
  return { display: `$${usd.toLocaleString('en-US')}`, converted: true };
}

const METHOD_ICONS: Record<PaymentMethod, typeof Smartphone> = {
  upi: Smartphone,
  cashfree: Wallet,
  card: CreditCard,
  crypto: Bitcoin,
};

const ULTIMATE_PERKS = [
  'Unlimited journal writing',
  'Analyze your last 100 entries',
  'History-aware journal questions',
  'Deep emotional trend reports',
];

const UNABRIDGED_PERKS = [
  'Everything in Ultimate',
  'Fable 5 at full depth — the strongest model',
  'Choose the reflection effort per run',
  'Import your ChatGPT or Claude history',
  'Handwriting and sketching on the page',
];

interface PremiumModalProps {
  open: boolean;
  onClose: () => void;
  activeTier: SubscriptionTier | null;
  country: string;
  setCountry: (code: string) => void;
  customer: { name: string; email: string };
  /** Resolves true when payment completed inline, false when the browser is redirecting. */
  onPay: (method: PaymentMethod, phone: string, tier: SubscriptionTier, period: BillingPeriod) => Promise<boolean>;
  trialDaysLeft: number;
}

export function PremiumModal({
  open,
  onClose,
  activeTier,
  country,
  setCountry,
  customer,
  onPay,
  trialDaysLeft,
}: PremiumModalProps) {
  const [tier, setTier] = useState<SubscriptionTier>(activeTier || 'ultimate');
  const [method, setMethod] = useState<PaymentMethod>(() => defaultMethod(country));
  const [phone, setPhone] = useState('');
  const [period, setPeriod] = useState<BillingPeriod>('yearly');
  const [paymentError, setPaymentError] = useState('');
  const [paying, setPaying] = useState(false);
  const [redirecting, setRedirecting] = useState(false);
  const [status, setStatus] = useState<PaymentsStatus | null>(null);
  const [statusChecked, setStatusChecked] = useState(false);

  const methods = useMemo(() => availableMethods(country), [country]);

  useEffect(() => {
    if (open) {
      setTier(activeTier || 'ultimate');
      setPaymentError('');
      setRedirecting(false);
    }
  }, [open, activeTier]);

  // Find out whether checkout can even start, before the user invests any
  // effort in filling the form in.
  useEffect(() => {
    if (!open || statusChecked) return;
    let active = true;
    fetchPaymentsStatus().then((result) => {
      if (!active) return;
      setStatus(result);
      setStatusChecked(true);
    });
    return () => { active = false; };
  }, [open, statusChecked]);

  // Keep the selected method valid when the country changes (UPI is India-only).
  useEffect(() => {
    if (!isMethodAvailable(method, country)) setMethod(defaultMethod(country));
  }, [country, method]);

  if (!open) return null;

  const methodInfo = PAYMENT_METHODS.find((entry) => entry.id === method)!;
  const isCrypto = method === 'crypto';
  const chargePrice = getChargePrice(tier, country, method, period);
  const selectedPrice = chargePrice.display;
  const isUnabridged = tier === 'unabridged';
  const isAlreadyActive = activeTier === tier;
  const MethodIcon = METHOD_ICONS[method];

  const pay = async () => {
    setPaymentError('');

    // Google Play collects everything it needs in its own sheet. Demanding a
    // phone number first is both pointless and a dead end — it blocked the
    // purchase entirely, because the web methods default to requiring one.
    if (!isPlayBillingPlatform() && methodInfo.requiresPhone) {
      const digits = phone.replace(/\D/g, '');
      if (country === 'IN' && !/^\d{10}$/.test(digits)) {
        setPaymentError('Enter a valid 10-digit Indian mobile number.');
        return;
      }
      if (country !== 'IN' && !/^\d{8,15}$/.test(digits)) {
        setPaymentError('Enter a valid mobile number (8-15 digits, digits only).');
        return;
      }
    }

    setPaying(true);
    try {
      const completed = await onPay(method, phone, tier, period);
      if (completed) {
        onClose();
      } else {
        // The browser is navigating to a hosted checkout page.
        setRedirecting(true);
      }
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : 'Payment could not be completed. Please try again.');
    } finally {
      setPaying(false);
    }
  };

  const payLabel = isCrypto
    ? `Continue to crypto checkout · ${selectedPrice}`
    : `Pay ${selectedPrice}${method === 'upi' ? ' with UPI' : ''}`;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-[28px] border border-white/10 bg-gradient-to-b from-[#101010] to-[#050505] shadow-2xl animate-fadeIn">
        <div className="relative overflow-hidden rounded-t-[28px] px-7 pb-5 pt-8 text-center">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-[#C08060]/15 blur-3xl" />
          <button onClick={onClose} className="absolute right-4 top-4 rounded-full p-2 text-white/50 transition hover:bg-white/5 hover:text-white" aria-label="Close plans"><X className="h-5 w-5" /></button>
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-[#D4A088] to-[#A85E3C] shadow-lg shadow-[#C08060]/15"><Crown className="h-8 w-8 text-white" /></div>
          <h2 className="mt-4 font-serif text-3xl text-white">Choose your ThinkSharp plan</h2>
          <p className="mt-2 text-sm text-white/55">
            {trialDaysLeft > 0 ? `${trialDaysLeft} day${trialDaysLeft === 1 ? '' : 's'} left in your free trial.` : 'Unlock your journal and deeper reflection tools.'}
          </p>
        </div>

        <div className="px-5 sm:px-7">
          <div className="grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => setTier('ultimate')}
              className={`rounded-3xl border p-4 text-left transition ${tier === 'ultimate' ? 'border-[var(--accent)] bg-[var(--accent-soft)] shadow-lg shadow-[var(--accent)]/10' : 'border-white/10 bg-black hover:border-white/25'}`}
            >
              <div className="flex items-center justify-between gap-2"><span className="text-sm font-bold text-white">Ultimate</span>{tier === 'ultimate' && <Check className="h-4 w-4 text-[var(--accent)]" />}</div>
              <div className="mt-2 font-serif text-2xl text-white">{getMonthlyPrice('ultimate', country, period)}</div>
              <div className="text-[11px] text-white/45">per month{period === 'yearly' ? ', billed yearly' : ''}</div>
              <p className="mt-2 text-xs leading-5 text-white/55">Unlimited writing plus 100-entry personalized analysis.</p>
            </button>
            <button
              onClick={() => setTier('unabridged')}
              className={`relative rounded-3xl border p-4 text-left transition ${tier === 'unabridged' ? 'border-[var(--accent)] bg-[var(--accent-soft)] shadow-lg shadow-[var(--accent)]/10' : 'border-white/10 bg-black hover:border-white/25'}`}
            >
              <span className="absolute -top-2.5 left-4 rounded-full bg-[var(--accent)] px-2.5 py-1 text-[10px] font-bold text-white">UNABRIDGED</span>
              <div className="flex items-center justify-between gap-2"><span className="text-sm font-bold text-white">Unabridged</span>{tier === 'unabridged' ? <Check className="h-4 w-4 text-[var(--accent)]" /> : <Star className="h-4 w-4 text-white/50" />}</div>
              <div className="mt-2 font-serif text-2xl text-white">{getMonthlyPrice('unabridged', country, period)}</div>
              <div className="text-[11px] text-white/45">per month{period === 'yearly' ? ', billed yearly' : ''}</div>
              <p className="mt-2 text-xs leading-5 text-white/55">Fable 5 at full depth, selectable effort, imports, and handwriting.</p>
            </button>
          </div>

          <div className="mt-4 rounded-3xl border border-white/10 bg-black p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-white">{isUnabridged ? 'Unabridged' : 'Ultimate'}</div>
                <div className="mt-1 text-xs text-white/55">{isUnabridged ? 'Fable 5 at full depth, with the effort dial in your hands.' : 'Everything you need for unlimited journaling.'}</div>
              </div>
              <div className="text-right">
                <div className="font-serif text-xl text-[var(--accent)]">{selectedPrice}</div>
                <div className="text-[11px] text-white/45">{period === 'yearly' ? 'billed once, 12 months' : 'billed monthly'}</div>
              </div>
            </div>
            <div className="mt-4 grid gap-2">
              {(isUnabridged ? UNABRIDGED_PERKS : ULTIMATE_PERKS).map((perk) => (
                <div key={perk} className="flex items-center gap-2 text-xs text-white/70"><span className="flex h-4 w-4 items-center justify-center rounded-full bg-[var(--accent-soft)]"><Check className="h-3 w-3 text-[var(--accent)]" /></span>{perk}</div>
              ))}
            </div>
          </div>

          {/* Billing period. Monthly and yearly only — Google Play's longest
              subscription period is one year, so anything longer could not be
              sold through the Android build at all. */}
          <div className="mt-4 flex rounded-2xl border border-white/10 bg-black p-1">
            {BILLING_PERIODS.map((option) => (
              <button
                key={option.id}
                onClick={() => setPeriod(option.id)}
                className={`relative flex-1 rounded-xl py-2.5 text-sm font-semibold transition ${
                  period === option.id ? 'bg-[var(--accent)] text-white' : 'text-white/55 hover:text-white'
                }`}
              >
                {option.label}
                {option.save > 0 && (
                  <span className={`ml-1.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                    period === option.id ? 'bg-white/20 text-white' : 'bg-[var(--accent-soft)] text-[var(--accent)]'
                  }`}>
                    −{option.save}%
                  </span>
                )}
              </button>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-center gap-2">
            <Globe className="h-4 w-4 shrink-0 text-white/45" />
            <select value={country} onChange={(event) => setCountry(event.target.value)} className="rounded-xl border border-white/10 bg-black px-3 py-2 text-sm text-white outline-none focus:border-[var(--accent)]">
              {PRICING.map((price) => <option className="bg-black text-white" key={price.code} value={price.code}>{price.flag} {price.name}</option>)}
            </select>
          </div>
        </div>

        <div className="p-5 sm:p-7">
          {isPlayBillingPlatform() ? (
            /* Android: Google Play runs the whole checkout — its own sheet, its
               own payment methods, its own prices. Showing a UPI/card/crypto
               picker here would be both misleading and against Play policy. */
            <div className="space-y-3">
              <div className="rounded-2xl border border-white/10 bg-black p-4">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-[var(--accent)]" />
                  Billed through Google Play
                </div>
                <p className="mt-1.5 text-xs leading-5 text-white/55">
                  Google Play handles the payment and the receipt, using whatever method is on your
                  Play account. Manage or cancel any time in the Play Store.
                </p>
              </div>
              {paymentError && <p className="rounded-xl bg-red-500/10 px-3 py-2 text-xs text-red-300">{paymentError}</p>}
              <button
                onClick={pay}
                disabled={paying}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-base font-bold text-white shadow-lg shadow-[var(--accent)]/20 transition hover:scale-[1.02] disabled:opacity-60"
              >
                {paying ? <><Loader2 className="h-5 w-5 animate-spin" /> Opening Google Play…</> : `Subscribe · ${selectedPrice}`}
              </button>
            </div>
          ) : statusChecked && !status?.anyLive ? (
            /* Payments are not configured on the backend. Saying so here is far
               better than letting someone reach the last step of a checkout
               that will refuse them with a raw server error. */
            <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4">
              <div className="flex items-center gap-2 text-sm font-bold text-amber-300">
                <AlertTriangle className="h-4 w-4" />
                Payments aren’t switched on yet
              </div>
              <p className="mt-1.5 text-xs leading-5 text-white/60">
                ThinkSharp can’t take payments on this build, so nothing will be charged and no plan can be
                started. Everything you’ve already written stays exactly where it is.
              </p>
            </div>
          ) : isAlreadyActive ? (
            <div className="flex items-center justify-center gap-2 rounded-2xl border border-[var(--accent)]/30 bg-[var(--accent-soft)] py-3.5 text-sm font-semibold text-[var(--accent)]"><Sparkles className="h-4 w-4" /> {tier === 'unabridged' ? 'Fable 5 is active' : 'Ultimate is active'}</div>
          ) : redirecting ? (
            <div className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-black py-4 text-sm text-white/70"><Loader2 className="h-4 w-4 animate-spin" /> Opening your crypto checkout…</div>
          ) : (
            <div className="space-y-3">
              {/* ---------- Payment method picker ---------- */}
              <div>
                <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-white/45">Payment method</div>
                <div className="grid grid-cols-2 gap-2">
                  {methods.map((entry) => {
                    const Icon = METHOD_ICONS[entry.id];
                    const selected = method === entry.id;
                    return (
                      <button
                        key={entry.id}
                        onClick={() => { setMethod(entry.id); setPaymentError(''); }}
                        className={`rounded-2xl border p-3 text-left transition ${selected ? 'border-[var(--accent)] bg-[var(--accent-soft)]' : 'border-white/10 bg-black hover:border-white/25'}`}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className={`h-4 w-4 shrink-0 ${selected ? 'text-[var(--accent)]' : 'text-white/50'}`} />
                          <span className="text-xs font-bold text-white">{entry.label}</span>
                          {selected && <Check className="ml-auto h-3.5 w-3.5 text-[var(--accent)]" />}
                        </div>
                        <p className="mt-1.5 text-[10px] leading-4 text-white/45">{entry.tagline}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* ---------- Method detail ---------- */}
              <div className="rounded-2xl border border-white/10 bg-black p-4 text-left">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-[var(--accent)]" />
                  {isCrypto ? 'Secure crypto checkout' : `Secure ${methodInfo.label} checkout`}
                </div>
                <p className="mt-1 flex items-start gap-1.5 text-xs leading-5 text-white/55">
                  <MethodIcon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-white/40" />
                  <span>
                    {isCrypto
                      ? 'You will be sent to a hosted crypto checkout. Pay in BTC, ETH, USDC and more — the amount is locked in USD at checkout.'
                      : 'Cashfree opens its secure payment window next. Your card and UPI details never touch ThinkSharp.'}
                  </span>
                </p>

                {chargePrice.converted && (
                  <p className="mt-2 rounded-xl bg-white/[0.04] px-3 py-2 text-[11px] leading-4 text-white/55">
                    Billed as <span className="font-semibold text-white/75">{selectedPrice} USD</span> — {getTotalPrice(tier, country, period)} is the local equivalent. Your bank or wallet handles the conversion.
                  </p>
                )}

                {methodInfo.requiresPhone && (
                  <>
                    <label className="mt-3 block text-[11px] font-semibold uppercase tracking-wide text-white/55">
                      {country === 'IN' ? 'Indian mobile number' : 'Mobile number'}
                    </label>
                    <div className="relative mt-1.5">
                      <Phone className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-white/45" />
                      <input
                        value={phone}
                        onChange={(event) => setPhone(event.target.value)}
                        inputMode="numeric"
                        maxLength={country === 'IN' ? 10 : 15}
                        placeholder={country === 'IN' ? '9876543210' : '2025550142'}
                        className="w-full rounded-xl border border-white/10 bg-black py-2.5 pl-9 pr-3 text-sm text-white outline-none focus:border-[var(--accent)]"
                      />
                    </div>
                    <p className="mt-1.5 text-[10px] text-white/35">Required by the payment processor for receipts and fraud checks.</p>
                  </>
                )}
              </div>

              {status?.mode === 'sandbox' && (
                <p className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-3 py-2 text-[11px] leading-4 text-amber-200/90">
                  Test mode — real cards will be declined and no money moves.
                </p>
              )}
              {statusChecked && isUnabridged && status && !status.tiers.unabridged && (
                <p className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-3 py-2 text-[11px] leading-4 text-amber-200/90">
                  Unabridged isn’t available on this build yet. Ultimate can still be purchased.
                </p>
              )}
              {paymentError && <p className="rounded-xl bg-red-500/10 px-3 py-2 text-xs text-red-300">{paymentError}</p>}

              <button
                onClick={pay}
                disabled={paying || (statusChecked && status ? !status.methods[method] : false)}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--accent)] py-4 text-base font-bold text-white shadow-lg shadow-[var(--accent)]/20 transition hover:scale-[1.02] disabled:opacity-60"
              >
                {paying ? <><Loader2 className="h-5 w-5 animate-spin" /> Opening checkout…</> : payLabel}
              </button>
            </div>
          )}
          {!isAlreadyActive && <p className="mt-3 text-center text-[11px] text-white/40">The server chooses and verifies the selected plan price before access is granted.</p>}
          <p className="mt-2 text-center text-[11px] text-white/35">Signed in as {customer.email}</p>
        </div>
      </div>
    </div>
  );
}
