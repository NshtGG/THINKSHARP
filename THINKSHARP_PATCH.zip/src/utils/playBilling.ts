import type { BillingPeriod, SubscriptionTier } from './payments';

/**
 * Google Play Billing.
 *
 * Google Play requires that digital goods consumed inside an Android app are
 * sold through Play's own billing system. Cashfree and Coinbase are fine on the
 * web, but shipping them as the in-app purchase path is what gets a listing
 * rejected — and, if it slips through, removed later.
 *
 * So ThinkSharp has two checkouts and picks by platform:
 *   Android build  -> Play Billing (this file)
 *   Web            -> Cashfree / Coinbase (payments.ts)
 *
 * The two never mix, and neither is a fallback for the other.
 */

/** Product IDs. These must match the subscription IDs created in Play Console. */
export const PLAY_PRODUCTS: Record<SubscriptionTier, Record<BillingPeriod, string>> = {
  ultimate: {
    monthly: 'thinksharp_ultimate_monthly',
    yearly: 'thinksharp_ultimate_yearly',
  },
  unabridged: {
    monthly: 'thinksharp_unabridged_monthly',
    yearly: 'thinksharp_unabridged_yearly',
  },
};

export function playProductId(tier: SubscriptionTier, period: BillingPeriod): string {
  return PLAY_PRODUCTS[tier][period];
}

export type PlayProduct = {
  id: string;
  tier: SubscriptionTier;
  period: BillingPeriod;
  /** Localised price string straight from Play, e.g. "₹2,000.00". */
  price: string;
  title: string;
  owned: boolean;
};

export type PlayPurchase = {
  productId: string;
  purchaseToken: string;
  tier: SubscriptionTier;
  period: BillingPeriod;
};

/* --------------------------- platform detection --------------------------- */

type CapacitorGlobal = {
  isNativePlatform?: () => boolean;
  getPlatform?: () => string;
};

function capacitor(): CapacitorGlobal | undefined {
  return (window as unknown as { Capacitor?: CapacitorGlobal }).Capacitor;
}

/**
 * True only inside the packaged Android app. On the web this is false, and the
 * Cashfree path is used instead.
 */
export function isPlayBillingPlatform(): boolean {
  const cap = capacitor();
  return Boolean(cap?.isNativePlatform?.() && cap?.getPlatform?.() === 'android');
}

/* ------------------------------ store bridge ------------------------------ */

/**
 * cordova-plugin-purchase exposes itself as `CdvPurchase` on window. It is only
 * present in the native build, so everything here is defensive — the web bundle
 * must never throw because the plugin is absent.
 */
type CdvProduct = {
  id: string;
  title?: string;
  owned?: boolean;
  pricing?: { price?: string };
  offers?: { pricingPhases?: { price?: string }[] }[];
  getOffer?: () => unknown;
};

type CdvTransaction = { purchaseId?: string; transactionId?: string; products?: { id: string }[] };
type CdvReceipt = { transactions?: CdvTransaction[]; verify?: () => void; finish?: () => void };

type CdvPurchaseGlobal = {
  store: {
    register: (products: { id: string; type: string; platform: string }[]) => void;
    initialize: (platforms: string[]) => Promise<void>;
    update: () => Promise<void>;
    get: (id: string) => CdvProduct | undefined;
    order: (offer: unknown) => Promise<unknown>;
    when: () => {
      approved: (cb: (t: CdvTransaction & { finish: () => void; verify: () => void }) => void) => unknown;
      verified: (cb: (r: CdvReceipt) => void) => unknown;
      finished: (cb: (t: CdvTransaction) => void) => unknown;
    };
    restorePurchases: () => Promise<unknown>;
  };
  ProductType: { PAID_SUBSCRIPTION: string };
  Platform: { GOOGLE_PLAY: string };
};

function cdv(): CdvPurchaseGlobal | undefined {
  return (window as unknown as { CdvPurchase?: CdvPurchaseGlobal }).CdvPurchase;
}

let initialised = false;
let initialising: Promise<boolean> | null = null;

/** Maps a Play product id back to the tier/period it represents. */
function describe(productId: string): { tier: SubscriptionTier; period: BillingPeriod } | null {
  for (const tier of ['ultimate', 'unabridged'] as SubscriptionTier[]) {
    for (const period of ['monthly', 'yearly'] as BillingPeriod[]) {
      if (PLAY_PRODUCTS[tier][period] === productId) return { tier, period };
    }
  }
  return null;
}

/**
 * Registers the four subscriptions and connects to Play. Safe to call more than
 * once; safe to call on the web, where it resolves false immediately.
 */
export async function initPlayBilling(): Promise<boolean> {
  if (!isPlayBillingPlatform()) return false;
  if (initialised) return true;
  if (initialising) return initialising;

  initialising = (async () => {
    const api = cdv();
    if (!api) return false;
    try {
      const all = Object.values(PLAY_PRODUCTS).flatMap((byPeriod) => Object.values(byPeriod));
      api.store.register(
        all.map((id) => ({
          id,
          type: api.ProductType.PAID_SUBSCRIPTION,
          platform: api.Platform.GOOGLE_PLAY,
        })),
      );
      await api.store.initialize([api.Platform.GOOGLE_PLAY]);
      initialised = true;
      return true;
    } catch (error) {
      console.error('Play Billing failed to initialise:', error);
      return false;
    } finally {
      initialising = null;
    }
  })();

  return initialising;
}

/** Prices as Play reports them, already localised and tax-inclusive per market. */
export async function getPlayProducts(): Promise<PlayProduct[]> {
  if (!(await initPlayBilling())) return [];
  const api = cdv();
  if (!api) return [];

  const out: PlayProduct[] = [];
  for (const tier of ['ultimate', 'unabridged'] as SubscriptionTier[]) {
    for (const period of ['monthly', 'yearly'] as BillingPeriod[]) {
      const id = PLAY_PRODUCTS[tier][period];
      const product = api.store.get(id);
      if (!product) continue;
      const price =
        product.pricing?.price ||
        product.offers?.[0]?.pricingPhases?.[0]?.price ||
        '';
      out.push({
        id,
        tier,
        period,
        price,
        title: product.title || id,
        owned: Boolean(product.owned),
      });
    }
  }
  return out;
}

/**
 * Starts Play's purchase sheet and resolves once the transaction is approved.
 *
 * The token it returns is NOT proof of anything on its own — it has to be
 * checked against Google's Play Developer API server-side before access is
 * granted. See netlify/functions/verify-play-purchase.mjs.
 */
export async function purchaseWithPlay(
  tier: SubscriptionTier,
  period: BillingPeriod,
): Promise<PlayPurchase> {
  if (!(await initPlayBilling())) {
    throw new Error('Google Play billing is unavailable on this device.');
  }
  const api = cdv();
  if (!api) throw new Error('Google Play billing is unavailable on this device.');

  const id = playProductId(tier, period);
  const product = api.store.get(id);
  if (!product) {
    throw new Error('That plan is not available on this device yet. Please try again shortly.');
  }

  return new Promise<PlayPurchase>((resolve, reject) => {
    let settled = false;
    const timeout = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error('The Play purchase did not complete. If you were charged, reopen ThinkSharp to restore it.'));
      }
    }, 5 * 60 * 1000);

    api.store.when().approved((transaction) => {
      if (settled) return;
      const productId = transaction.products?.[0]?.id || id;
      const meta = describe(productId);
      const purchaseToken = transaction.purchaseId || transaction.transactionId || '';
      if (!meta || !purchaseToken) return;
      settled = true;
      window.clearTimeout(timeout);
      // Left unfinished on purpose: acknowledge only after the server has
      // verified it. Play auto-refunds a subscription that is never
      // acknowledged within three days, which is the correct outcome if our
      // verification never succeeds.
      resolve({ productId, purchaseToken, tier: meta.tier, period: meta.period });
    });

    const offer = product.getOffer ? product.getOffer() : product.offers?.[0];
    if (!offer) {
      settled = true;
      window.clearTimeout(timeout);
      reject(new Error('That plan has no active offer on Google Play.'));
      return;
    }

    api.store.order(offer).catch((error: unknown) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timeout);
      const message = error instanceof Error ? error.message : String(error);
      // The user backing out of Play's sheet is not an error worth shouting about.
      reject(new Error(/cancel/i.test(message) ? 'Purchase cancelled.' : message));
    });
  });
}

/** Re-reads entitlements from Play — for reinstalls and new devices. */
export async function restorePlayPurchases(): Promise<PlayPurchase[]> {
  if (!(await initPlayBilling())) return [];
  const api = cdv();
  if (!api) return [];
  try {
    await api.store.restorePurchases();
    const products = await getPlayProducts();
    return products
      .filter((p) => p.owned)
      .map((p) => ({ productId: p.id, purchaseToken: '', tier: p.tier, period: p.period }));
  } catch (error) {
    console.error('Restoring Play purchases failed:', error);
    return [];
  }
}

/* ---------------------------- server verification ------------------------- */

const viteEnv = (import.meta as unknown as { env?: Record<string, string | undefined> }).env;
const verifyPlayEndpoint =
  viteEnv?.VITE_PLAY_VERIFY_ENDPOINT || '/.netlify/functions/verify-play-purchase';

export type PlayVerification = {
  isPaid: boolean;
  subscriptionState: string;
  subscriptionTier?: SubscriptionTier;
  billingPeriod?: BillingPeriod;
  entitlementToken?: string | null;
  expiresAt?: number | null;
};

/**
 * Asks our backend to confirm the purchase with Google before anything unlocks.
 * The client never decides its own entitlement.
 */
export async function verifyPlayPurchase(
  purchase: PlayPurchase,
  email: string,
): Promise<PlayVerification> {
  const response = await fetch(verifyPlayEndpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      productId: purchase.productId,
      purchaseToken: purchase.purchaseToken,
      email,
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error((payload as { error?: string }).error || 'That purchase could not be verified.');
  }
  return payload as PlayVerification;
}

/**
 * Whether a backend is configured to verify Play purchases.
 *
 * Server verification is the stronger design and stays the default whenever a
 * backend exists. But *requiring* one would mean nobody can buy anything until
 * a server is deployed — so with no verify endpoint configured we fall back to
 * Play's own on-device receipt.
 *
 * That fallback is weaker: a modified APK could fake ownership. It is not a
 * regression though, because entitlement in ThinkSharp already lives on the
 * device, and it is how a great many small Android apps ship.
 */
export function hasVerificationBackend(): boolean {
  return Boolean(viteEnv?.VITE_PLAY_VERIFY_ENDPOINT);
}

/** Confirms a purchase from what Play itself reports, with no server involved. */
export async function verifyWithPlayLocally(purchase: PlayPurchase): Promise<PlayVerification> {
  const products = await getPlayProducts();
  const owned = products.find((p) => p.id === purchase.productId)?.owned;
  const months = purchase.period === 'yearly' ? 12 : 1;
  return {
    isPaid: Boolean(owned),
    subscriptionState: owned ? 'SUBSCRIPTION_STATE_ACTIVE' : 'SUBSCRIPTION_STATE_UNKNOWN',
    subscriptionTier: purchase.tier,
    billingPeriod: purchase.period,
    // No server means no signed entitlement, so AI summaries stay locked until
    // a backend exists. Everything else in the tier unlocks.
    entitlementToken: null,
    expiresAt: Date.now() + months * 31 * 24 * 60 * 60 * 1000,
  };
}

/** Acknowledge the transaction once the purchase is confirmed. */
export function finishPlayTransaction(productId: string): void {
  const api = cdv();
  if (!api) return;
  try {
    const product = api.store.get(productId) as unknown as { transaction?: { finish?: () => void } };
    product?.transaction?.finish?.();
  } catch (error) {
    console.error('Could not acknowledge the Play transaction:', error);
  }
}
