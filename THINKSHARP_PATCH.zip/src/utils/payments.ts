export type PaymentMethod = 'upi' | 'cashfree' | 'card' | 'crypto';

export type SubscriptionTier = 'ultimate' | 'unabridged';

/** Monthly and yearly only — Play's longest subscription period is one year. */
export type BillingPeriod = 'monthly' | 'yearly';

export const BILLING_PERIODS: { id: BillingPeriod; label: string; months: number; rate: number; save: number }[] = [
  { id: 'monthly', label: 'Monthly', months: 1, rate: 1, save: 0 },
  { id: 'yearly', label: 'Yearly', months: 12, rate: 0.85, save: 15 },
];

export type PaymentCustomer = {
  email: string;
  name: string;
  phone: string;
};

export type OrderResponse = {
  provider: 'cashfree' | 'coinbase';
  orderId: string;
  billingPeriod?: BillingPeriod;
  months?: number;
  paymentSessionId?: string;
  hostedUrl?: string;
  mode?: 'sandbox' | 'production';
  subscriptionTier: SubscriptionTier;
  method: PaymentMethod;
  amount: number;
  currency: string;
};

export type VerificationResponse = {
  provider: 'cashfree' | 'coinbase';
  orderId: string;
  orderStatus: string;
  isPaid: boolean;
  isExpired?: boolean;
  subscriptionTier?: SubscriptionTier;
  country?: string | null;
  entitlementToken?: string | null;
  expiresAt?: number | null;
};

/**
 * Cashfree flows finish inside a modal, so they resolve with a verified
 * payment. Crypto hands off to a hosted page, so the browser navigates away
 * and picks the order back up on return.
 */
export type PaymentResult =
  | { kind: 'verified'; verification: VerificationResponse }
  | { kind: 'redirected' };

const viteEnv = (import.meta as unknown as { env?: Record<string, string | undefined> }).env;
const orderEndpoint =
  viteEnv?.VITE_PAYMENT_ORDER_ENDPOINT || '/.netlify/functions/create-payment-order';
const verifyEndpoint =
  viteEnv?.VITE_PAYMENT_VERIFY_ENDPOINT || '/.netlify/functions/verify-payment-order';

const PENDING_KEY = 'thinksharp_pending_order';

/* ------------------------------ Method catalog ---------------------------- */

export type PaymentMethodInfo = {
  id: PaymentMethod;
  label: string;
  tagline: string;
  /** Cashfree needs a contact number; Coinbase does not. */
  requiresPhone: boolean;
};

export const PAYMENT_METHODS: PaymentMethodInfo[] = [
  { id: 'upi', label: 'UPI', tagline: 'GPay, PhonePe, Paytm — India only', requiresPhone: true },
  { id: 'cashfree', label: 'Cashfree Checkout', tagline: 'Cards, wallets, netbanking', requiresPhone: true },
  { id: 'card', label: 'Debit / Credit Card', tagline: 'Visa, Mastercard, Amex, RuPay', requiresPhone: true },
  { id: 'crypto', label: 'Crypto', tagline: 'BTC, ETH, USDC and more', requiresPhone: false },
];

/**
 * Local currency per market. Mirrors MARKETS in netlify/functions/lib/payments.mjs
 * — keep the two in sync if you add a country.
 */
export const LOCAL_CURRENCY: Record<string, string> = {
  US: 'USD', GB: 'GBP', EU: 'EUR', CA: 'CAD', AU: 'AUD', IN: 'INR',
  BR: 'BRL', JP: 'JPY', CN: 'CNY', MX: 'MXN', NG: 'NGN', ID: 'IDR',
  PH: 'PHP', PK: 'PKR', VN: 'VND', TR: 'TRY',
};

/**
 * Currencies a Cashfree merchant can typically accept. Markets outside this
 * list are charged the USD equivalent instead. Mirrors
 * DEFAULT_CASHFREE_CURRENCIES on the server.
 */
export const CASHFREE_LOCAL_CURRENCIES = [
  'INR', 'USD', 'EUR', 'GBP', 'CAD', 'AUD', 'SGD', 'AED', 'JPY',
];

/**
 * Which currency the customer's card/wallet is actually debited in.
 * Crypto always settles in USD; Cashfree falls back to USD where the local
 * currency is not enabled.
 */
export function chargeCurrency(_tier: SubscriptionTier, country: string, method: PaymentMethod): string {
  if (method === 'crypto') return 'USD';
  const local = LOCAL_CURRENCY[country] || 'USD';
  return CASHFREE_LOCAL_CURRENCIES.includes(local) ? local : 'USD';
}

/** UPI is India-only. Everything else works in every supported market. */
export function isMethodAvailable(method: PaymentMethod, country: string): boolean {
  if (method === 'upi') return country === 'IN';
  return true;
}

export function availableMethods(country: string): PaymentMethodInfo[] {
  return PAYMENT_METHODS.filter((method) => isMethodAvailable(method.id, country));
}

export function defaultMethod(country: string): PaymentMethod {
  return country === 'IN' ? 'upi' : 'cashfree';
}

/* --------------------------- Pending order memory -------------------------- */

export type PendingOrder = {
  orderId: string;
  tier: SubscriptionTier;
  period?: BillingPeriod;
  method: PaymentMethod;
  createdAt: number;
};

export function savePendingOrder(order: PendingOrder): void {
  try {
    localStorage.setItem(PENDING_KEY, JSON.stringify(order));
  } catch {
    // Storage is unavailable; verification can still run from the return URL.
  }
}

export function readPendingOrder(): PendingOrder | null {
  try {
    const raw = localStorage.getItem(PENDING_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PendingOrder;
    if (!parsed?.orderId) return null;
    // Abandoned checkouts should not haunt the app forever.
    if (Date.now() - (parsed.createdAt || 0) > 6 * 60 * 60 * 1000) {
      clearPendingOrder();
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function clearPendingOrder(): void {
  try {
    localStorage.removeItem(PENDING_KEY);
  } catch {
    // ignore
  }
}

/* -------------------------------- Cashfree -------------------------------- */

type CashfreeCheckoutResult = {
  error?: { message?: string };
  redirect?: boolean;
  paymentDetails?: { paymentMessage?: string };
};

type CashfreeInstance = {
  checkout: (options: {
    paymentSessionId: string;
    redirectTarget: '_modal';
  }) => Promise<CashfreeCheckoutResult>;
};

declare global {
  interface Window {
    Cashfree?: (options: { mode: 'sandbox' | 'production' }) => CashfreeInstance;
  }
}

function loadCashfreeSdk(): Promise<void> {
  if (window.Cashfree) return Promise.resolve();

  return new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>('script[data-cashfree-sdk]');
    if (existing) {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Cashfree checkout failed to load.')), { once: true });
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://sdk.cashfree.com/js/v3/cashfree.js';
    script.async = true;
    script.dataset.cashfreeSdk = 'true';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Cashfree checkout failed to load. Check your internet connection.'));
    document.head.appendChild(script);
  });
}

/* --------------------------------- Core ---------------------------------- */

async function readJson<T>(response: Response): Promise<T> {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      (payload as { error?: string }).error ||
      (payload as { message?: string }).message ||
      'This payment could not be processed.';
    throw new Error(message);
  }
  return payload as T;
}

export async function verifyPaymentOrder(orderId: string): Promise<VerificationResponse> {
  const response = await fetch(`${verifyEndpoint}?order_id=${encodeURIComponent(orderId)}`);
  return readJson<VerificationResponse>(response);
}

/**
 * Payment status lags slightly behind the moment a user approves a UPI request
 * or a crypto transaction is broadcast, so poll before giving up.
 */
export async function waitForPaidOrder(
  orderId: string,
  attempts = 18,
  intervalMs = 2000,
): Promise<VerificationResponse> {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, attempt === 0 ? 1200 : intervalMs));
    const verification = await verifyPaymentOrder(orderId);
    if (verification.isPaid) return verification;
    if (verification.isExpired || ['EXPIRED', 'TERMINATED', 'CANCELED'].includes(verification.orderStatus)) {
      throw new Error('This payment session has expired. Please start a new checkout.');
    }
  }

  throw new Error('Payment is still pending. Finish the payment, then reopen ThinkSharp to confirm it.');
}

export async function createPaymentOrder(options: {
  customer: PaymentCustomer;
  subscriptionTier: SubscriptionTier;
  method: PaymentMethod;
  country: string;
  billingPeriod: BillingPeriod;
}): Promise<OrderResponse> {
  const response = await fetch(orderEndpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      customer: options.customer,
      subscriptionTier: options.subscriptionTier,
      method: options.method,
      country: options.country,
      billingPeriod: options.billingPeriod,
    }),
  });
  return readJson<OrderResponse>(response);
}

export async function startPayment(options: {
  customer: PaymentCustomer;
  subscriptionTier: SubscriptionTier;
  method: PaymentMethod;
  country: string;
  billingPeriod: BillingPeriod;
}): Promise<PaymentResult> {
  const order = await createPaymentOrder(options);

  savePendingOrder({
    orderId: order.orderId,
    tier: order.subscriptionTier,
    period: order.billingPeriod,
    method: order.method,
    createdAt: Date.now(),
  });

  // Crypto: hand off to the hosted Coinbase Commerce page.
  if (order.provider === 'coinbase') {
    if (!order.hostedUrl) throw new Error('The crypto checkout could not be opened. Please try again.');
    window.location.assign(order.hostedUrl);
    return { kind: 'redirected' };
  }

  // Cashfree: UPI, card and full checkout all run in the same modal.
  if (!order.paymentSessionId) throw new Error('Cashfree did not return a checkout session. Please try again.');

  await loadCashfreeSdk();
  if (!window.Cashfree) throw new Error('Cashfree checkout did not initialize. Please try again.');

  const cashfree = window.Cashfree({ mode: order.mode || 'sandbox' });
  const checkoutResult = await cashfree.checkout({
    paymentSessionId: order.paymentSessionId,
    redirectTarget: '_modal',
  });

  if (checkoutResult.error) {
    throw new Error(checkoutResult.error.message || 'Payment was cancelled or could not be started.');
  }

  const verification = await waitForPaidOrder(order.orderId);
  clearPendingOrder();
  return { kind: 'verified', verification };
}

/* --------------------------- Configuration state -------------------------- */

export type PaymentsStatus = {
  methods: Record<PaymentMethod, boolean>;
  tiers: { ultimate: boolean; unabridged: boolean };
  mode: 'sandbox' | 'production' | null;
  anyLive: boolean;
  missing: string[];
};

const statusEndpoint =
  viteEnv?.VITE_PAYMENT_STATUS_ENDPOINT || '/.netlify/functions/payments-status';

/**
 * Asks the backend which rails are live, so the plan screen can say "payments
 * aren't set up yet" before someone fills in a phone number and taps Pay.
 * A failure here means the backend is unreachable, which is itself a "not
 * live" answer.
 */
export async function fetchPaymentsStatus(): Promise<PaymentsStatus | null> {
  try {
    const response = await fetch(statusEndpoint);
    if (!response.ok) return null;
    return (await response.json()) as PaymentsStatus;
  } catch {
    return null;
  }
}

/* --------------------------- Recurring subscriptions ---------------------- */

/**
 * Cashfree mandate types. UPI Autopay first because it has by far the best
 * completion rate in India — approval happens inside the customer's own UPI app
 * with no bank forms.
 */
export type MandateMethod = 'upi' | 'card' | 'enach';

export const MANDATE_METHODS: { id: MandateMethod; label: string; tagline: string; indiaOnly: boolean }[] = [
  { id: 'upi', label: 'UPI Autopay', tagline: 'Approve once in GPay, PhonePe or Paytm', indiaOnly: true },
  { id: 'card', label: 'Card on file', tagline: 'Visa, Mastercard, Amex, RuPay', indiaOnly: false },
  { id: 'enach', label: 'Bank account', tagline: 'Direct debit via eNACH', indiaOnly: true },
];

export function availableMandateMethods(country: string) {
  return MANDATE_METHODS.filter((m) => !m.indiaOnly || country === 'IN');
}

export type SubscriptionResponse = {
  subscriptionId: string;
  status: string;
  authLink: string | null;
  sessionId: string | null;
  tier: SubscriptionTier;
  period: BillingPeriod;
  recurringAmount: number;
  currency: string;
};

export type SubscriptionVerification = {
  subscriptionId: string;
  subscriptionStatus: string;
  isPaid: boolean;
  isExpired: boolean;
  subscriptionTier?: SubscriptionTier;
  nextPaymentOn?: string | null;
  entitlementToken?: string | null;
  expiresAt?: number | null;
};

const createSubEndpoint =
  viteEnv?.VITE_SUBSCRIPTION_CREATE_ENDPOINT || '/.netlify/functions/create-subscription';
const verifySubEndpoint =
  viteEnv?.VITE_SUBSCRIPTION_VERIFY_ENDPOINT || '/.netlify/functions/verify-subscription';

const PENDING_SUB_KEY = 'thinksharp_pending_subscription';

export function savePendingSubscription(id: string): void {
  try { localStorage.setItem(PENDING_SUB_KEY, JSON.stringify({ id, at: Date.now() })); } catch { /* ignore */ }
}

export function readPendingSubscription(): string | null {
  try {
    const raw = localStorage.getItem(PENDING_SUB_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { id: string; at: number };
    // A mandate can take a couple of days to be approved by a bank, so this
    // window is much longer than the one-off checkout window.
    if (Date.now() - (parsed.at || 0) > 7 * 24 * 60 * 60 * 1000) {
      clearPendingSubscription();
      return null;
    }
    return parsed.id || null;
  } catch { return null; }
}

export function clearPendingSubscription(): void {
  try { localStorage.removeItem(PENDING_SUB_KEY); } catch { /* ignore */ }
}

/** Sets up the mandate. Nothing is charged until the customer approves it. */
export async function startSubscription(options: {
  customer: PaymentCustomer;
  subscriptionTier: SubscriptionTier;
  billingPeriod: BillingPeriod;
  method: MandateMethod;
  country: string;
}): Promise<SubscriptionResponse> {
  const response = await fetch(createSubEndpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(options),
  });
  const result = await readJson<SubscriptionResponse>(response);
  savePendingSubscription(result.subscriptionId);
  return result;
}

export async function verifySubscription(subscriptionId: string): Promise<SubscriptionVerification> {
  const response = await fetch(`${verifySubEndpoint}?subscription_id=${encodeURIComponent(subscriptionId)}`);
  return readJson<SubscriptionVerification>(response);
}
